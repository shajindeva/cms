using CMS.Application.Interfaces;
using CMS.Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CMS.Api.Controllers;

[ApiController]
[Route("api/tickets")]
[Authorize]
public class TicketsController : ControllerBase
{
    private readonly ITicketService _tickets;

    public TicketsController(ITicketService tickets) => _tickets = tickets;

    [HttpGet]
    public async Task<IActionResult> Search([FromQuery] string? q, [FromQuery] Guid? departmentId, [FromQuery] string? status, [FromQuery] string? priority, [FromQuery] string? sla, [FromQuery] int page = 1, [FromQuery] int pageSize = 20)
    {
        var (items, total) = await _tickets.SearchAsync(q, departmentId, status, priority, sla, page, pageSize);
        return Ok(new { total, items });
    }

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Detail(Guid id)
    {
        var t = await _tickets.GetDetailAsync(id);
        return t is null ? NotFound() : Ok(t);
    }

    [HttpPost("{id:guid}/assign")]
    [Authorize(Roles = RoleNames.Admin + "," + RoleNames.Supervisor)]
    public async Task<IActionResult> Assign(Guid id, [FromBody] AssignRequest req)
    {
        var actor = User.Identity?.Name ?? "user";
        await _tickets.AssignAsync(id, req.AssigneeUserId, req.Reason ?? "", actor);
        return NoContent();
    }

    [HttpPost("{id:guid}/update")]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdateRequest req)
    {
        var actor = User.Claims.FirstOrDefault(c => c.Type == "displayName")?.Value ?? (User.Identity?.Name ?? "user");

        // Restrict close/reopen to central/admin/supervisor as per internal workflow.
        if (req.Status != null && req.Status.Equals("Closed", StringComparison.OrdinalIgnoreCase))
        {
            var isAllowed = User.IsInRole(RoleNames.Admin) || User.IsInRole(RoleNames.Supervisor) || User.IsInRole(RoleNames.Central);
            if (!isAllowed) return Forbid();
        }

        await _tickets.UpdateAsync(id, actor, req.Status, req.Priority, req.ResolutionSummary, req.ClosureReason, req.RootCauseCategory);
        return NoContent();
    }

    [HttpPost("{id:guid}/comment")]
    public async Task<IActionResult> Comment(Guid id, [FromBody] CommentRequest req)
    {
        var actor = User.Claims.FirstOrDefault(c => c.Type == "displayName")?.Value ?? (User.Identity?.Name ?? "user");
        var userId = User.Claims.FirstOrDefault(c => c.Type == System.IdentityModel.Tokens.Jwt.JwtRegisteredClaimNames.Sub)?.Value;

        await _tickets.AddCommentAsync(id, actor, userId, req.IsInternal, req.Message);
        return NoContent();
    }

    [HttpPost("{id:guid}/escalate")]
    [Authorize(Roles = RoleNames.Admin + "," + RoleNames.Supervisor + "," + RoleNames.L1Agent + "," + RoleNames.L2Agent + "," + RoleNames.L3Agent)]
    public async Task<IActionResult> Escalate(Guid id, [FromBody] EscalateRequest req)
    {
        var actor = User.Claims.FirstOrDefault(c => c.Type == "displayName")?.Value ?? (User.Identity?.Name ?? "user");
        await _tickets.EscalateAsync(id, actor, req.Reason, req.Emergency);
        return NoContent();
    }

    [HttpPost("{id:guid}/reopen")]
    [Authorize(Roles = RoleNames.Admin + "," + RoleNames.Supervisor + "," + RoleNames.Central)]
    public async Task<IActionResult> Reopen(Guid id, [FromBody] ReopenRequest req)
    {
        var actor = User.Claims.FirstOrDefault(c => c.Type == "displayName")?.Value ?? (User.Identity?.Name ?? "user");
        await _tickets.ReopenAsync(id, actor, req.Reason);
        return NoContent();
    }

    public record AssignRequest(string AssigneeUserId, string? Reason);
    public record UpdateRequest(string? Status, string? Priority, string? ResolutionSummary, string? ClosureReason, string? RootCauseCategory);
    public record CommentRequest(bool IsInternal, string Message);
    public record EscalateRequest(string Reason, bool Emergency);
    public record ReopenRequest(string Reason);
}
