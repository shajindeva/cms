using CMS.Application.DTOs;
using CMS.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

namespace CMS.Api.Controllers;

[ApiController]
[Route("api/public")]
public class PublicController : ControllerBase
{
    private readonly ITicketService _tickets;
    private readonly IAdminService _admin;
    private readonly IFileStorage _storage;
    private readonly CMS.Infrastructure.Data.AppDbContext _db;

    private static readonly HashSet<string> AllowedExtensions = new(StringComparer.OrdinalIgnoreCase)
    {
        ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".jpg", ".jpeg", ".png"
    };

    public PublicController(ITicketService tickets, IAdminService admin, IFileStorage storage, CMS.Infrastructure.Data.AppDbContext db)
    {
        _tickets = tickets;
        _admin = admin;
        _storage = storage;
        _db = db;
    }

    [HttpGet("metadata")]
    [EnableRateLimiting("public")]
    public async Task<IActionResult> Metadata()
    {
        var depts = await _admin.GetDepartmentsAsync();
        var cats = await _admin.GetCategoriesAsync(null);
        return Ok(new
        {
            departments = depts.Select(d => new { d.Id, d.Name }),
            categories = cats.Select(c => new { c.Id, c.Name, c.DepartmentId })
        });
    }

    [HttpPost("upload")]
    [RequestSizeLimit(10 * 1024 * 1024)]
    [EnableRateLimiting("public")]
    public async Task<IActionResult> Upload([FromQuery] Guid ticketId, [FromForm] IFormFile file)
    {
        if (file is null || file.Length == 0) return BadRequest("File missing.");
        var ext = Path.GetExtension(file.FileName);
        if (!AllowedExtensions.Contains(ext)) return BadRequest("File type not allowed.");
        if (file.Length > 10 * 1024 * 1024) return BadRequest("File too large.");

        var actor = HttpContext.Connection.RemoteIpAddress?.ToString() ?? "Customer";
        var att = await _storage.SaveTicketAttachmentAsync(ticketId, file, isCustomerUpload: true, actor);
        _db.TicketAttachments.Add(att);
        await _db.SaveChangesAsync();

        return Ok(new { att.Id, att.FileName, att.SizeBytes });
    }

    [HttpPost("complaints")]
    [EnableRateLimiting("public")]
    public async Task<IActionResult> Create([FromBody] PublicCreateTicketRequest request)
    {
        var ip = HttpContext.Connection.RemoteIpAddress?.ToString();
        var ticketNumber = await _tickets.CreatePublicTicketAsync(request, ip);
        return Ok(new { ticketNumber });
    }

    [HttpPost("track")]
    [EnableRateLimiting("public")]
    public async Task<IActionResult> Track([FromBody] PublicTrackRequest request)
    {
        var result = await _tickets.TrackAsync(request);
        return result is null ? NotFound() : Ok(result);
    }
}
