using CMS.Application.Interfaces;
using CMS.Domain;
using CMS.Domain.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CMS.Api.Controllers;

[ApiController]
[Route("api/admin")]
[Authorize(Roles = RoleNames.Admin)]
public class AdminController : ControllerBase
{
    private readonly IAdminService _admin;

    public AdminController(IAdminService admin) => _admin = admin;

    [HttpGet("departments")]
    public async Task<IActionResult> Departments() => Ok(await _admin.GetDepartmentsAsync());

    [HttpPost("departments")]
    public async Task<IActionResult> UpsertDepartment([FromBody] Department dept) => Ok(await _admin.UpsertDepartmentAsync(dept));

    [HttpGet("categories")]
    public async Task<IActionResult> Categories([FromQuery] Guid? departmentId) => Ok(await _admin.GetCategoriesAsync(departmentId));

    [HttpPost("categories")]
    public async Task<IActionResult> UpsertCategory([FromBody] IssueCategory cat) => Ok(await _admin.UpsertCategoryAsync(cat));

    [HttpGet("sla")]
    public async Task<IActionResult> Sla() => Ok(await _admin.GetSlaMatrixAsync());

    [HttpPost("sla")]
    public async Task<IActionResult> UpsertSla([FromBody] SlaMatrixCell cell) => Ok(await _admin.UpsertSlaCellAsync(cell));

    [HttpGet("email-templates")]
    public async Task<IActionResult> EmailTemplates() => Ok(await _admin.GetEmailTemplatesAsync());

    [HttpPost("email-templates")]
    public async Task<IActionResult> UpsertEmailTemplate([FromBody] EmailTemplate template) => Ok(await _admin.UpsertEmailTemplateAsync(template));
}
