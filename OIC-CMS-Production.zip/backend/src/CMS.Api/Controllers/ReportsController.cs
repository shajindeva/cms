using CMS.Application.Interfaces;
using CMS.Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CMS.Api.Controllers;

[ApiController]
[Route("api/reports")]
[Authorize]
public class ReportsController : ControllerBase
{
    private readonly IReportingService _reports;

    public ReportsController(IReportingService reports) => _reports = reports;

    [HttpGet("dashboard")]
    public async Task<IActionResult> Dashboard([FromQuery] int days = 30, [FromQuery] Guid? departmentId = null)
    {
        var kpis = await _reports.GetDashboardKpisAsync(days, departmentId);
        var trend = await _reports.GetTrendAsync(days, departmentId);
        return Ok(new { kpis, trend });
    }

    [HttpGet("tickets.csv")]
    [Authorize(Roles = RoleNames.Admin + "," + RoleNames.Supervisor + "," + RoleNames.Auditor)]
    public async Task<IActionResult> ExportCsv([FromQuery] DateTime? fromUtc, [FromQuery] DateTime? toUtc, [FromQuery] Guid? departmentId)
    {
        var bytes = await _reports.ExportTicketsCsvAsync(fromUtc, toUtc, departmentId);
        return File(bytes, "text/csv", $"CMS_Tickets_{DateTime.UtcNow:yyyyMMdd}.csv");
    }
}
