using CMS.Infrastructure.Security;
using Microsoft.EntityFrameworkCore;

namespace CMS.Infrastructure.Data;

public static class AuthDbContextExtensions
{
    public static ModelBuilder AddRefreshTokens(this ModelBuilder b)
    {
        b.Entity<RefreshToken>().ToTable("RefreshTokens");
        b.Entity<RefreshToken>().HasKey(x => x.Id);
        b.Entity<RefreshToken>().HasIndex(x => x.TokenHash).IsUnique();
        b.Entity<RefreshToken>().HasIndex(x => x.UserId);
        return b;
    }
}
