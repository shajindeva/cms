using CMS.Domain.Entities;
using CMS.Infrastructure.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace CMS.Infrastructure.Data;

public class AppDbContext : IdentityDbContext<AppUser>
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) {}

    public DbSet<Ticket> Tickets => Set<Ticket>();
    public DbSet<TicketComment> TicketComments => Set<TicketComment>();
    public DbSet<TicketAttachment> TicketAttachments => Set<TicketAttachment>();
    public DbSet<TicketEscalation> TicketEscalations => Set<TicketEscalation>();
    public DbSet<Department> Departments => Set<Department>();
    public DbSet<IssueCategory> IssueCategories => Set<IssueCategory>();
    public DbSet<SlaMatrixCell> SlaMatrix => Set<SlaMatrixCell>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();
    public DbSet<EmailTemplate> EmailTemplates => Set<EmailTemplate>();
    public DbSet<EmailLog> EmailLogs => Set<EmailLog>();
    public DbSet<CMS.Infrastructure.Security.RefreshToken> RefreshTokens => Set<CMS.Infrastructure.Security.RefreshToken>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        base.OnModelCreating(b);

        b.Entity<Department>().HasIndex(x => x.Name).IsUnique();
        b.Entity<IssueCategory>().HasIndex(x => new { x.DepartmentId, x.Name }).IsUnique();
        b.Entity<Ticket>().HasIndex(x => x.TicketNumber).IsUnique();
        b.Entity<SlaMatrixCell>().HasIndex(x => new { x.Priority, x.SupportLevel }).IsUnique();

        b.Entity<Ticket>()
            .HasMany(x => x.Comments)
            .WithOne(x => x.Ticket!)
            .HasForeignKey(x => x.TicketId);

        b.Entity<Ticket>()
            .HasMany(x => x.Attachments)
            .WithOne(x => x.Ticket!)
            .HasForeignKey(x => x.TicketId);

        b.Entity<Ticket>()
            .HasMany(x => x.Escalations)
            .WithOne(x => x.Ticket!)
            .HasForeignKey(x => x.TicketId);

        // store enums as strings for readability
        b.Entity<Ticket>().Property(x => x.Priority).HasConversion<string>();
        b.Entity<Ticket>().Property(x => x.Status).HasConversion<string>();
        b.Entity<Ticket>().Property(x => x.SupportLevel).HasConversion<string>();
        b.Entity<Ticket>().Property(x => x.SlaState).HasConversion<string>();

        b.Entity<SlaMatrixCell>().Property(x => x.Priority).HasConversion<string>();
        b.Entity<SlaMatrixCell>().Property(x => x.SupportLevel).HasConversion<string>();

        // Refresh tokens
        b.Entity<CMS.Infrastructure.Security.RefreshToken>().ToTable("RefreshTokens");
        b.Entity<CMS.Infrastructure.Security.RefreshToken>().HasKey(x => x.Id);
        b.Entity<CMS.Infrastructure.Security.RefreshToken>().HasIndex(x => x.TokenHash).IsUnique();
        b.Entity<CMS.Infrastructure.Security.RefreshToken>().HasIndex(x => x.UserId);
    }
}
