using CMS.Domain;
using CMS.Domain.Entities;
using CMS.Infrastructure.Email;
using CMS.Infrastructure.Identity;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace CMS.Infrastructure.Data;

public static class DbInitializer
{
    public static async Task InitializeAsync(AppDbContext db, UserManager<AppUser> users, RoleManager<IdentityRole> roles)
    {
        // NOTE: For first run without migrations, you can use EnsureCreated. Prefer migrations in real production.
        await db.Database.EnsureCreatedAsync();

        // Roles
        var roleNames = new[] { RoleNames.Admin, RoleNames.Supervisor, RoleNames.L1Agent, RoleNames.L2Agent, RoleNames.L3Agent, RoleNames.Auditor, RoleNames.Central };
        foreach (var r in roleNames)
        {
            if (!await roles.RoleExistsAsync(r))
                await roles.CreateAsync(new IdentityRole(r));
        }

        // Departments & categories (based on mock UI + SOW)
        if (!await db.Departments.AnyAsync())
        {
            var departments = new[]
            {
                new Department { Name = "Customer Service", NotificationEmail = "cs@oic.ae" },
                new Department { Name = "Claims", NotificationEmail = "claims@oic.ae" },
                new Department { Name = "Finance & Billing", NotificationEmail = "finance@oic.ae" },
                new Department { Name = "Technical Support", NotificationEmail = "it@oic.ae" },
                new Department { Name = "Underwriting", NotificationEmail = "uw@oic.ae" },
                new Department { Name = "Sales", NotificationEmail = "sales@oic.ae" },
                new Department { Name = "Compliance & Legal", NotificationEmail = "compliance@oic.ae" },
                new Department { Name = "Operations", NotificationEmail = "ops@oic.ae" }
            };
            db.Departments.AddRange(departments);
            await db.SaveChangesAsync();

            // minimal categories for each dept
            var map = new Dictionary<string, string[]>
            {
                ["Customer Service"] = new[] { "Policy Enquiry", "Service Quality", "Renewal Issue", "Policy Cancellation", "Document Request" },
                ["Claims"] = new[] { "Claim Delay", "Claim Rejection", "Claim Amount Dispute", "Missing Documents", "Claim Status Update" },
                ["Finance & Billing"] = new[] { "Incorrect Invoice", "Refund Request", "Payment Issue", "Direct Debit Error" },
                ["Technical Support"] = new[] { "Portal Access Issue", "App Not Working", "Data Discrepancy", "System Error" },
                ["Underwriting"] = new[] { "Premium Dispute", "Coverage Query", "Policy Amendment", "Underwriting Decision" },
                ["Sales"] = new[] { "Mis-selling Complaint", "Quotation Issue", "Agent Conduct" },
                ["Operations"] = new[] { "Processing Delay", "Communication Failure" },
                ["Compliance & Legal"] = new[] { "Regulatory Complaint", "Data Privacy Concern" }
            };

            foreach (var d in departments)
            {
                foreach (var c in map[d.Name])
                {
                    db.IssueCategories.Add(new IssueCategory { DepartmentId = d.Id, Name = c });
                }
            }
            await db.SaveChangesAsync();
        }

        // SLA Matrix (default values; admin can override)
        if (!await db.SlaMatrix.AnyAsync())
        {
            var cells = new List<SlaMatrixCell>();
            void add(Priority p, SupportLevel l, decimal ack, decimal res, int warn) => cells.Add(new SlaMatrixCell { Priority = p, SupportLevel = l, AcknowledgementHours = ack, ResolutionHours = res, WarningThresholdPercent = warn });

            add(Priority.Critical, SupportLevel.L1, 0.5m, 4m, 75);
            add(Priority.Critical, SupportLevel.L2, 0.25m, 2m, 75);
            add(Priority.Critical, SupportLevel.L3, 0.25m, 1m, 70);

            add(Priority.High, SupportLevel.L1, 1m, 8m, 80);
            add(Priority.High, SupportLevel.L2, 0.5m, 4m, 80);
            add(Priority.High, SupportLevel.L3, 0.5m, 2m, 75);

            add(Priority.Medium, SupportLevel.L1, 4m, 24m, 80);
            add(Priority.Medium, SupportLevel.L2, 2m, 12m, 80);
            add(Priority.Medium, SupportLevel.L3, 1m, 6m, 80);

            add(Priority.Low, SupportLevel.L1, 8m, 48m, 85);
            add(Priority.Low, SupportLevel.L2, 4m, 24m, 85);
            add(Priority.Low, SupportLevel.L3, 2m, 12m, 85);

            db.SlaMatrix.AddRange(cells);
            await db.SaveChangesAsync();
        }

        // Email templates
        if (!await db.EmailTemplates.AnyAsync())
        {
            db.EmailTemplates.AddRange(new[]
            {
                new EmailTemplate { Key = "TicketCreatedCustomer", Subject = "Your complaint {{TicketNumber}} has been received", BodyHtml = "<p>Dear {{CustomerName}},</p><p>We have received your complaint <strong>{{TicketNumber}}</strong>.</p><p>Subject: {{Subject}}</p><p>You can track your complaint using your Ticket Number and Email.</p><p>Regards,<br/>OIC CMS</p>" },
                new EmailTemplate { Key = "TicketCreatedInternal", Subject = "New complaint {{TicketNumber}} ({{Department}})", BodyHtml = "<p>New complaint created: <strong>{{TicketNumber}}</strong></p><p>Department: {{Department}}</p><p>Subject: {{Subject}}</p><p>Customer: {{CustomerEmail}}</p>" },
                new EmailTemplate { Key = "TicketAssignedInternal", Subject = "Ticket {{TicketNumber}} assigned to {{Assignee}}", BodyHtml = "<p>Ticket <strong>{{TicketNumber}}</strong> has been assigned to {{Assignee}}.</p><p>Reason: {{Reason}}</p>" },
                new EmailTemplate { Key = "TicketEscalatedInternal", Subject = "Ticket {{TicketNumber}} escalated {{From}} → {{To}}", BodyHtml = "<p>Ticket <strong>{{TicketNumber}}</strong> escalated from {{From}} to {{To}}.</p><p>Emergency: {{Emergency}}</p><p>Reason: {{Reason}}</p>" },
                new EmailTemplate { Key = "TicketStatusCustomer", Subject = "Update on your complaint {{TicketNumber}}", BodyHtml = "<p>Your complaint <strong>{{TicketNumber}}</strong> status changed to <strong>{{Status}}</strong>.</p><p>Subject: {{Subject}}</p><p>Regards,<br/>OIC CMS</p>" },
                new EmailTemplate { Key = "TicketCommentCustomer", Subject = "New update on {{TicketNumber}}", BodyHtml = "<p>There is a new update on your complaint <strong>{{TicketNumber}}</strong>:</p><blockquote>{{Message}}</blockquote>" },
                new EmailTemplate { Key = "TicketReopenedCustomer", Subject = "Your complaint {{TicketNumber}} has been reopened", BodyHtml = "<p>Your complaint <strong>{{TicketNumber}}</strong> has been reopened.</p><p>Reason: {{Reason}}</p>" },
            });
            await db.SaveChangesAsync();
        }

        // Default admin
        if (!await users.Users.AnyAsync())
        {
            var admin = new AppUser
            {
                UserName = "admin",
                Email = "admin@oic.ae",
                DisplayName = "System Administrator",
                EmailConfirmed = true,
                IsActive = true
            };
            await users.CreateAsync(admin, "ChangeMe!12345");
            await users.AddToRolesAsync(admin, new[] { RoleNames.Admin, RoleNames.Central });

            // Sample supervisor
            var sup = new AppUser
            {
                UserName = "supervisor",
                Email = "supervisor@oic.ae",
                DisplayName = "Supervisor",
                EmailConfirmed = true,
                IsActive = true
            };
            await users.CreateAsync(sup, "ChangeMe!12345");
            await users.AddToRolesAsync(sup, new[] { RoleNames.Supervisor, RoleNames.Central });
        }
    }
}
