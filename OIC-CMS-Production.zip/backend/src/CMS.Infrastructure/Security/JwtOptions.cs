namespace CMS.Infrastructure.Security;

public class JwtOptions
{
    public string Issuer { get; set; } = "CMS";
    public string Audience { get; set; } = "CMS";
    public string SigningKey { get; set; } = "CHANGE_ME__A_VERY_LONG_RANDOM_SECRET";
    public int AccessTokenMinutes { get; set; } = 20;
    public int RefreshTokenDays { get; set; } = 7;
}
