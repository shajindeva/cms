using CMS.Application.DTOs;
using CMS.Application.Interfaces;
using CMS.Domain;
using CMS.Domain.Entities;
using CMS.Infrastructure.Identity;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace CMS.Infrastructure.Services;

public class TicketService : ITicketService
{
    private readonly Data.AppDbContext _db;
    private readonly ITicketNumberGenerator _ticketNumber;
    private readonly IEmailComposer _emailComposer;
    private readonly IEmailSender _emailSender;
    private readonly IAuditWriter _audit;
    private readonly ISlaEngine _sla;
    private readonly UserManager<AppUser> _userManager;

    public TicketService(
        Data.AppDbContext db,
        ITicketNumberGenerator ticketNumber,
        IEmailComposer emailComposer,
        IEmailSender emailSender,
        IAuditWriter audit,
        ISlaEngine sla,
        UserManager<AppUser> userManager)
    {
        _db = db;
        _ticketNumber = ticketNumber;
        _emailComposer = emailComposer;
        _emailSender = emailSender;
        _audit = audit;
        _sla = sla;
        _userManager = userManager;
    }

    public async Task<string> CreatePublicTicketAsync(PublicCreateTicketRequest request, string? createdByIp)
    {
        var dept = await _db.Departments.FirstAsync(d => d.Id == request.DepartmentId && d.IsActive);
        var cat = await _db.IssueCategories.FirstAsync(c => c.Id == request.IssueCategoryId && c.IsActive);

        var ticketNumber = await _ticketNumber.NextAsync();
        var ticket = new Ticket
        {
            TicketNumber = ticketNumber,
            CustomerName = request.CustomerName,
            CustomerEmail = request.CustomerEmail,
            CustomerMobile = request.CustomerMobile,
            DepartmentId = dept.Id,
            IssueCategoryId = cat.Id,
            Subject = request.Subject,
            Description = request.Description,
            Status = TicketStatus.New,
            SupportLevel = SupportLevel.L1,
            Priority = Priority.Medium,
            SlaStartAtUtc = DateTime.UtcNow,
            CreatedBy = createdByIp
        };

        _db.Tickets.Add(ticket);
        await _db.SaveChangesAsync();

        await _audit.WriteAsync("TicketCreated", actor: "System", ticketId: ticket.Id, to: ticket.TicketNumber, source: "PublicPortal");

        await _sla.RecalculateAndPersistAsync(ticket.Id);

        // Customer acknowledgement email
        var (subj, body) = await _emailComposer.ComposeAsync("TicketCreatedCustomer", new Dictionary<string, string>
        {
            ["TicketNumber"] = ticket.TicketNumber,
            ["CustomerName"] = ticket.CustomerName,
            ["Subject"] = ticket.Subject
        });
        await _emailSender.SendAsync(ticket.CustomerEmail, subj, body);

        // Internal notify department (optional)
        if (!string.IsNullOrWhiteSpace(dept.NotificationEmail))
        {
            var (isub, ibody) = await _emailComposer.ComposeAsync("TicketCreatedInternal", new Dictionary<string, string>
            {
                ["TicketNumber"] = ticket.TicketNumber,
                ["Department"] = dept.Name,
                ["Subject"] = ticket.Subject,
                ["CustomerEmail"] = ticket.CustomerEmail
            });
            await _emailSender.SendAsync(dept.NotificationEmail!, isub, ibody);
        }

        return ticket.TicketNumber;
    }

    public async Task<PublicTicketView?> TrackAsync(PublicTrackRequest request)
    {
        var t = await _db.Tickets
            .Include(x => x.Department)
            .Include(x => x.Comments)
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.TicketNumber == request.TicketNumber && x.CustomerEmail == request.CustomerEmail);

        if (t is null) return null;

        // Only customer-visible timeline (exclude internal notes)
        var tl = t.Comments
            .Where(c => !c.IsInternal)
            .OrderBy(c => c.CreatedAtUtc)
            .Select(c => new PublicTimelineItem { AtUtc = c.CreatedAtUtc, Message = c.Message })
            .ToList();

        return new PublicTicketView
        {
            TicketNumber = t.TicketNumber,
            Subject = t.Subject,
            Department = t.Department?.Name ?? "",
            Status = t.Status,
            CreatedAtUtc = t.CreatedAtUtc,
            UpdatedAtUtc = t.UpdatedAtUtc,
            Timeline = tl
        };
    }

    public async Task<(IReadOnlyList<TicketListItem> Items, int Total)> SearchAsync(string? q, Guid? deptId, string? status, string? priority, string? sla, int page, int pageSize)
    {
        var query = _db.Tickets
            .Include(t => t.Department)
            .Include(t => t.IssueCategory)
            .AsNoTracking()
            .AsQueryable();

        if (!string.IsNullOrWhiteSpace(q))
        {
            q = q.Trim();
            query = query.Where(t => t.TicketNumber.Contains(q) || t.CustomerEmail.Contains(q) || t.CustomerName.Contains(q) || t.Subject.Contains(q));
        }

        if (deptId.HasValue)
            query = query.Where(t => t.DepartmentId == deptId.Value);

        if (!string.IsNullOrWhiteSpace(status) && Enum.TryParse<TicketStatus>(status.Replace(" ", string.Empty), ignoreCase: true, out var st))
            query = query.Where(t => t.Status == st);

        if (!string.IsNullOrWhiteSpace(priority) && Enum.TryParse<Priority>(priority, true, out var pr))
            query = query.Where(t => t.Priority == pr);

        if (!string.IsNullOrWhiteSpace(sla) && Enum.TryParse<SlaState>(sla, true, out var ss))
            query = query.Where(t => t.SlaState == ss);

        var total = await query.CountAsync();
        var items = await query
            .OrderByDescending(t => t.CreatedAtUtc)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(t => new TicketListItem
            {
                Id = t.Id,
                TicketNumber = t.TicketNumber,
                Subject = t.Subject,
                CustomerName = t.CustomerName,
                CustomerEmail = t.CustomerEmail,
                Department = t.Department!.Name,
                Category = t.IssueCategory!.Name,
                Priority = t.Priority,
                Status = t.Status,
                SupportLevel = t.SupportLevel,
                AssignedTo = t.AssignedToUserId,
                SlaState = t.SlaState,
                CreatedAtUtc = t.CreatedAtUtc,
                SlaDueAtUtc = t.SlaDueAtUtc
            })
            .ToListAsync();

        return (items, total);
    }

    public async Task<TicketDetailView?> GetDetailAsync(Guid id)
    {
        var t = await _db.Tickets
            .Include(x => x.Department)
            .Include(x => x.IssueCategory)
            .Include(x => x.Comments)
            .Include(x => x.Attachments)
            .Include(x => x.Escalations)
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.Id == id);

        if (t is null) return null;

        string? assignedName = null;
        if (!string.IsNullOrEmpty(t.AssignedToUserId))
        {
            var u = await _userManager.Users.AsNoTracking().FirstOrDefaultAsync(x => x.Id == t.AssignedToUserId);
            assignedName = u?.DisplayName;
        }

        return new TicketDetailView
        {
            Id = t.Id,
            TicketNumber = t.TicketNumber,
            CustomerName = t.CustomerName,
            CustomerEmail = t.CustomerEmail,
            CustomerMobile = t.CustomerMobile,
            Department = t.Department?.Name ?? "",
            Category = t.IssueCategory?.Name ?? "",
            Subject = t.Subject,
            Description = t.Description,
            Priority = t.Priority,
            Status = t.Status,
            SupportLevel = t.SupportLevel,
            AssignedToUserId = t.AssignedToUserId,
            AssignedToDisplayName = assignedName,
            SlaState = t.SlaState,
            SlaStartAtUtc = t.SlaStartAtUtc,
            SlaDueAtUtc = t.SlaDueAtUtc,
            CreatedAtUtc = t.CreatedAtUtc,
            UpdatedAtUtc = t.UpdatedAtUtc,
            AcknowledgedAtUtc = t.AcknowledgedAtUtc,
            ResolvedAtUtc = t.ResolvedAtUtc,
            ClosedAtUtc = t.ClosedAtUtc,
            ReopenCount = t.ReopenCount,
            ResolutionSummary = t.ResolutionSummary,
            ClosureReason = t.ClosureReason,
            RootCauseCategory = t.RootCauseCategory,
            Comments = t.Comments.OrderBy(c => c.CreatedAtUtc).Select(c => new TicketCommentView { AtUtc = c.CreatedAtUtc, Author = c.AuthorDisplayName, IsInternal = c.IsInternal, Message = c.Message }).ToList(),
            Attachments = t.Attachments.OrderByDescending(a => a.CreatedAtUtc).Select(a => new TicketAttachmentView { Id = a.Id, FileName = a.FileName, ContentType = a.ContentType, SizeBytes = a.SizeBytes, IsCustomerUpload = a.IsCustomerUpload, AtUtc = a.CreatedAtUtc }).ToList(),
            Escalations = t.Escalations.OrderByDescending(e => e.CreatedAtUtc).Select(e => new TicketEscalationView { AtUtc = e.CreatedAtUtc, By = e.CreatedBy ?? "", From = e.FromLevel.ToString(), To = e.ToLevel.ToString(), IsEmergency = e.IsEmergency, Reason = e.Reason }).ToList()
        };
    }

    public async Task AssignAsync(Guid ticketId, string assigneeUserId, string reason, string actor)
    {
        var t = await _db.Tickets.FirstAsync(x => x.Id == ticketId);
        var from = t.AssignedToUserId;
        t.AssignedToUserId = assigneeUserId;
        if (t.Status == TicketStatus.New)
        {
            t.Status = TicketStatus.Assigned;
        }
        t.UpdatedAtUtc = DateTime.UtcNow;
        t.UpdatedBy = actor;

        await _db.SaveChangesAsync();
        await _audit.WriteAsync("AssigneeChanged", actor, t.Id, "AssignedToUserId", from, assigneeUserId);

        // Email internal assignment
        var assignee = await _userManager.Users.AsNoTracking().FirstOrDefaultAsync(u => u.Id == assigneeUserId);
        if (assignee is not null && !string.IsNullOrWhiteSpace(assignee.Email))
        {
            var (subj, body) = await _emailComposer.ComposeAsync("TicketAssignedInternal", new Dictionary<string, string>
            {
                ["TicketNumber"] = t.TicketNumber,
                ["Subject"] = t.Subject,
                ["Reason"] = reason,
                ["Assignee"] = assignee.DisplayName
            });
            await _emailSender.SendAsync(assignee.Email!, subj, body);
        }

        await _sla.RecalculateAndPersistAsync(t.Id);
    }

    public async Task UpdateAsync(Guid ticketId, string actor, string? status, string? priority, string? resolutionSummary, string? closureReason, string? rootCauseCategory)
    {
        var t = await _db.Tickets.FirstAsync(x => x.Id == ticketId);

        if (!string.IsNullOrWhiteSpace(priority) && Enum.TryParse<Priority>(priority, true, out var pr) && t.Priority != pr)
        {
            var old = t.Priority;
            t.Priority = pr;
            await _audit.WriteAsync("PriorityChanged", actor, t.Id, "Priority", old.ToString(), pr.ToString());
        }

        if (!string.IsNullOrWhiteSpace(status))
        {
            var normalized = status.Replace(" ", string.Empty);
            if (Enum.TryParse<TicketStatus>(normalized, true, out var st) && t.Status != st)
            {
                var old = t.Status;

                // SLA pause/resume on PendingCustomer
                if (st == TicketStatus.PendingCustomer)
                {
                    t.IsSlaPaused = true;
                    t.SlaPausedAtUtc = DateTime.UtcNow;
                }
                else if (t.Status == TicketStatus.PendingCustomer && st != TicketStatus.PendingCustomer)
                {
                    // resume: shift SLA start by paused duration
                    if (t.SlaPausedAtUtc.HasValue)
                    {
                        var paused = DateTime.UtcNow - t.SlaPausedAtUtc.Value;
                        t.SlaStartAtUtc = t.SlaStartAtUtc.Add(paused);
                    }
                    t.IsSlaPaused = false;
                    t.SlaPausedAtUtc = null;
                }

                t.Status = st;

                if (st == TicketStatus.Acknowledged && t.AcknowledgedAtUtc is null)
                    t.AcknowledgedAtUtc = DateTime.UtcNow;

                if (st == TicketStatus.Resolved && t.ResolvedAtUtc is null)
                    t.ResolvedAtUtc = DateTime.UtcNow;

                if (st == TicketStatus.Closed && t.ClosedAtUtc is null)
                    t.ClosedAtUtc = DateTime.UtcNow;

                await _audit.WriteAsync("StatusChanged", actor, t.Id, "Status", old.ToString(), st.ToString());
            }
        }

        if (!string.IsNullOrWhiteSpace(resolutionSummary))
            t.ResolutionSummary = resolutionSummary;
        if (!string.IsNullOrWhiteSpace(closureReason))
            t.ClosureReason = closureReason;
        if (!string.IsNullOrWhiteSpace(rootCauseCategory))
            t.RootCauseCategory = rootCauseCategory;

        t.UpdatedAtUtc = DateTime.UtcNow;
        t.UpdatedBy = actor;
        await _db.SaveChangesAsync();

        await _sla.RecalculateAndPersistAsync(t.Id);

        // Customer notification on customer-visible updates
        var notifyStatuses = new[] { TicketStatus.Acknowledged, TicketStatus.PendingCustomer, TicketStatus.Resolved, TicketStatus.Closed };
        if (status is not null)
        {
            var normalized = status.Replace(" ", string.Empty);
            if (Enum.TryParse<TicketStatus>(normalized, true, out var st) && notifyStatuses.Contains(st))
            {
                var (subj, body) = await _emailComposer.ComposeAsync("TicketStatusCustomer", new Dictionary<string, string>
                {
                    ["TicketNumber"] = t.TicketNumber,
                    ["Status"] = st.ToString(),
                    ["Subject"] = t.Subject
                });
                await _emailSender.SendAsync(t.CustomerEmail, subj, body);
            }
        }
    }

    public async Task AddCommentAsync(Guid ticketId, string actorDisplayName, string? actorUserId, bool isInternal, string message)
    {
        var t = await _db.Tickets.FirstAsync(x => x.Id == ticketId);
        _db.TicketComments.Add(new TicketComment
        {
            TicketId = t.Id,
            AuthorDisplayName = actorDisplayName,
            AuthorUserId = actorUserId,
            IsInternal = isInternal,
            Message = message,
            CreatedAtUtc = DateTime.UtcNow,
            CreatedBy = actorDisplayName
        });

        t.UpdatedAtUtc = DateTime.UtcNow;
        t.UpdatedBy = actorDisplayName;

        await _db.SaveChangesAsync();
        await _audit.WriteAsync("CommentAdded", actorDisplayName, t.Id, to: isInternal ? "Internal" : "Public");

        // Optionally move to PendingCustomer when public comment requests info
        if (!isInternal && t.Status == TicketStatus.InProgress)
        {
            t.Status = TicketStatus.PendingCustomer;
            t.IsSlaPaused = true;
            t.SlaPausedAtUtc = DateTime.UtcNow;
            await _db.SaveChangesAsync();
        }

        // Notify customer if comment is public
        if (!isInternal)
        {
            var (subj, body) = await _emailComposer.ComposeAsync("TicketCommentCustomer", new Dictionary<string, string>
            {
                ["TicketNumber"] = t.TicketNumber,
                ["Message"] = message
            });
            await _emailSender.SendAsync(t.CustomerEmail, subj, body);
        }

        await _sla.RecalculateAndPersistAsync(t.Id);
    }

    public async Task EscalateAsync(Guid ticketId, string actor, string reason, bool emergency)
    {
        var t = await _db.Tickets.FirstAsync(x => x.Id == ticketId);
        var from = t.SupportLevel;

        SupportLevel to;
        if (emergency || from == SupportLevel.L3)
        {
            to = SupportLevel.L3;
        }
        else
        {
            to = from switch
            {
                SupportLevel.L1 => SupportLevel.L2,
                SupportLevel.L2 => SupportLevel.L3,
                _ => SupportLevel.L3
            };
            t.SupportLevel = to;
        }

        t.AssignedToUserId = null;

        // reset SLA window from escalation timestamp
        t.SlaStartAtUtc = DateTime.UtcNow;
        t.IsSlaPaused = false;
        t.SlaPausedAtUtc = null;

        _db.TicketEscalations.Add(new TicketEscalation
        {
            TicketId = t.Id,
            FromLevel = from,
            ToLevel = to,
            Reason = reason,
            IsEmergency = emergency,
            CreatedAtUtc = DateTime.UtcNow,
            CreatedBy = actor
        });

        await _db.SaveChangesAsync();
        await _audit.WriteAsync("Escalated", actor, t.Id, "SupportLevel", from.ToString(), to.ToString());
        await _sla.RecalculateAndPersistAsync(t.Id);

        // Notify internal stakeholders: department distribution list
        var dept = await _db.Departments.AsNoTracking().FirstAsync(d => d.Id == t.DepartmentId);
        if (!string.IsNullOrWhiteSpace(dept.NotificationEmail))
        {
            var (subj, body) = await _emailComposer.ComposeAsync("TicketEscalatedInternal", new Dictionary<string, string>
            {
                ["TicketNumber"] = t.TicketNumber,
                ["From"] = from.ToString(),
                ["To"] = to.ToString(),
                ["Reason"] = reason,
                ["Emergency"] = emergency ? "Yes" : "No"
            });
            await _emailSender.SendAsync(dept.NotificationEmail!, subj, body);
        }
    }

    public async Task ReopenAsync(Guid ticketId, string actor, string reason)
    {
        var t = await _db.Tickets.FirstAsync(x => x.Id == ticketId);
        t.Status = TicketStatus.Reopened;
        t.ReopenCount += 1;
        t.ClosedAtUtc = null;
        t.ResolvedAtUtc = null;
        t.SlaStartAtUtc = DateTime.UtcNow;
        t.IsSlaPaused = false;
        t.SlaPausedAtUtc = null;

        await _db.SaveChangesAsync();
        await _audit.WriteAsync("Reopened", actor, t.Id, to: reason);
        await _sla.RecalculateAndPersistAsync(t.Id);

        var (subj, body) = await _emailComposer.ComposeAsync("TicketReopenedCustomer", new Dictionary<string, string>
        {
            ["TicketNumber"] = t.TicketNumber,
            ["Reason"] = reason
        });
        await _emailSender.SendAsync(t.CustomerEmail, subj, body);
    }
}
