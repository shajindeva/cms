using CMS.Application.DTOs;
using CMS.Application.Interfaces;
using CMS.Infrastructure.Data;
using CMS.Infrastructure.Identity;
using CMS.Infrastructure.Security;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace CMS.Infrastructure.Services;

public class AuthService : IAuthService
{
    private readonly UserManager<AppUser> _userManager;
    private readonly AppDbContext _db;
    private readonly JwtOptions _jwt;

    public AuthService(UserManager<AppUser> userManager, AppDbContext db, IOptions<JwtOptions> jwt)
    {
        _userManager = userManager;
        _db = db;
        _jwt = jwt.Value;
    }

    public async Task<TokenResponse?> LoginAsync(LoginRequest request)
    {
        var user = await _userManager.Users.FirstOrDefaultAsync(u => u.UserName == request.Username && u.IsActive);
        if (user is null) return null;

        var ok = await _userManager.CheckPasswordAsync(user, request.Password);
        if (!ok) return null;

        return await IssueTokensAsync(user);
    }

    public async Task<TokenResponse?> RefreshAsync(RefreshRequest request)
    {
        var tokenHash = Hash(request.RefreshToken);
        var rt = await _db.RefreshTokens.FirstOrDefaultAsync(x => x.TokenHash == tokenHash);
        if (rt is null || !rt.IsActive) return null;

        var user = await _userManager.FindByIdAsync(rt.UserId);
        if (user is null || !user.IsActive) return null;

        // rotate
        rt.RevokedAtUtc = DateTime.UtcNow;
        var rotated = await CreateRefreshTokenAsync(user.Id);
        rt.ReplacedByTokenHash = rotated.TokenHash;

        await _db.SaveChangesAsync();

        var access = await CreateJwtAsync(user);
        return new TokenResponse
        {
            AccessToken = access.Token,
            ExpiresAtUtc = access.ExpiresAtUtc,
            RefreshToken = rotated.Plain
        };
    }

    public async Task LogoutAsync(string refreshToken)
    {
        var tokenHash = Hash(refreshToken);
        var rt = await _db.RefreshTokens.FirstOrDefaultAsync(x => x.TokenHash == tokenHash);
        if (rt is null) return;
        rt.RevokedAtUtc = DateTime.UtcNow;
        await _db.SaveChangesAsync();
    }

    private async Task<TokenResponse> IssueTokensAsync(AppUser user)
    {
        var access = await CreateJwtAsync(user);
        var refresh = await CreateRefreshTokenAsync(user.Id);
        return new TokenResponse
        {
            AccessToken = access.Token,
            ExpiresAtUtc = access.ExpiresAtUtc,
            RefreshToken = refresh.Plain
        };
    }

    private async Task<(string Token, DateTime ExpiresAtUtc)> CreateJwtAsync(AppUser user)
    {
        var roles = await _userManager.GetRolesAsync(user);
        var claims = new List<Claim>
        {
            new Claim(JwtRegisteredClaimNames.Sub, user.Id),
            new Claim(JwtRegisteredClaimNames.UniqueName, user.UserName ?? user.Email ?? user.Id),
            new Claim("displayName", user.DisplayName),
        };

        if (user.DepartmentId.HasValue)
            claims.Add(new Claim("departmentId", user.DepartmentId.Value.ToString()));

        if (user.SupportLevel.HasValue)
            claims.Add(new Claim("supportLevel", user.SupportLevel.Value.ToString()));

        foreach (var r in roles)
            claims.Add(new Claim(ClaimTypes.Role, r));

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwt.SigningKey));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
        var exp = DateTime.UtcNow.AddMinutes(_jwt.AccessTokenMinutes);

        var token = new JwtSecurityToken(
            issuer: _jwt.Issuer,
            audience: _jwt.Audience,
            claims: claims,
            expires: exp,
            signingCredentials: creds
        );

        return (new JwtSecurityTokenHandler().WriteToken(token), exp);
    }

    private async Task<(string Plain, string TokenHash)> CreateRefreshTokenAsync(string userId)
    {
        var plain = Convert.ToBase64String(RandomNumberGenerator.GetBytes(48));
        var hash = Hash(plain);

        var rt = new RefreshToken
        {
            UserId = userId,
            TokenHash = hash,
            ExpiresAtUtc = DateTime.UtcNow.AddDays(_jwt.RefreshTokenDays)
        };

        _db.RefreshTokens.Add(rt);
        await _db.SaveChangesAsync();
        return (plain, hash);
    }

    private static string Hash(string value)
    {
        using var sha = SHA256.Create();
        var bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(value));
        return Convert.ToHexString(bytes);
    }
}
