using CMS.Domain.Entities;

namespace CMS.Infrastructure.Services;

public interface IAuditWriter
{
    Task WriteAsync(string action, string actor, Guid? ticketId = null, string? field = null, string? from = null, string? to = null, string source = "API");
}

public class AuditWriter : IAuditWriter
{
    private readonly Data.AppDbContext _db;
    public AuditWriter(Data.AppDbContext db) => _db = db;

    public async Task WriteAsync(string action, string actor, Guid? ticketId = null, string? field = null, string? from = null, string? to = null, string source = "API")
    {
        _db.AuditLogs.Add(new AuditLog
        {
            Action = action,
            Actor = actor,
            TicketId = ticketId,
            Field = field,
            FromValue = from,
            ToValue = to,
            Source = source,
            CreatedAtUtc = DateTime.UtcNow,
            CreatedBy = actor
        });
        await _db.SaveChangesAsync();
    }
}
