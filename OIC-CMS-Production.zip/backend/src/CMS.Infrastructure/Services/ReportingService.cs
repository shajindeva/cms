using CMS.Application.Interfaces;
using CMS.Domain;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace CMS.Infrastructure.Services;

public class ReportingService : IReportingService
{
    private readonly Data.AppDbContext _db;
    public ReportingService(Data.AppDbContext db) => _db = db;

    public async Task<DashboardKpis> GetDashboardKpisAsync(int days, Guid? departmentId)
    {
        var from = DateTime.UtcNow.AddDays(-Math.Abs(days));
        var q = _db.Tickets.AsNoTracking().Where(t => t.CreatedAtUtc >= from);
        if (departmentId.HasValue) q = q.Where(t => t.DepartmentId == departmentId);

        var total = await q.CountAsync();
        var closed = await q.CountAsync(t => t.Status == TicketStatus.Closed);
        var open = await q.CountAsync(t => t.Status != TicketStatus.Closed);
        var breached = await q.CountAsync(t => t.SlaState == SlaState.Breached && t.Status != TicketStatus.Closed);
        var warning = await q.CountAsync(t => t.SlaState == SlaState.Warning && t.Status != TicketStatus.Closed);
        var criticalOpen = await q.CountAsync(t => t.Priority == Priority.Critical && t.Status != TicketStatus.Closed);

        decimal? sla = null;
        if (closed > 0)
        {
            var within = await q.CountAsync(t => t.Status == TicketStatus.Closed && t.SlaState != SlaState.Breached);
            sla = Math.Round((decimal)within / closed * 100, 2);
        }

        return new DashboardKpis(total, open, closed, breached, warning, criticalOpen, sla);
    }

    public async Task<IReadOnlyList<TrendPoint>> GetTrendAsync(int days, Guid? departmentId)
    {
        var start = DateTime.UtcNow.Date.AddDays(-Math.Abs(days) + 1);
        var end = DateTime.UtcNow.Date.AddDays(1);

        var q = _db.Tickets.AsNoTracking().Where(t => t.CreatedAtUtc >= start && t.CreatedAtUtc < end);
        if (departmentId.HasValue) q = q.Where(t => t.DepartmentId == departmentId);

        var created = await q
            .GroupBy(t => t.CreatedAtUtc.Date)
            .Select(g => new { Day = g.Key, Count = g.Count() })
            .ToListAsync();

        var closed = await _db.Tickets.AsNoTracking()
            .Where(t => t.ClosedAtUtc != null && t.ClosedAtUtc >= start && t.ClosedAtUtc < end)
            .Where(t => !departmentId.HasValue || t.DepartmentId == departmentId)
            .GroupBy(t => t.ClosedAtUtc!.Value.Date)
            .Select(g => new { Day = g.Key, Count = g.Count() })
            .ToListAsync();

        var mapCreated = created.ToDictionary(x => x.Day, x => x.Count);
        var mapClosed = closed.ToDictionary(x => x.Day, x => x.Count);

        var points = new List<TrendPoint>();
        for (var d = start; d < end; d = d.AddDays(1))
        {
            mapCreated.TryGetValue(d, out var c1);
            mapClosed.TryGetValue(d, out var c2);
            points.Add(new TrendPoint(d, c1, c2));
        }
        return points;
    }

    public async Task<byte[]> ExportTicketsCsvAsync(DateTime? fromUtc, DateTime? toUtc, Guid? departmentId)
    {
        var q = _db.Tickets.AsNoTracking().Include(t => t.Department).Include(t => t.IssueCategory).AsQueryable();
        if (fromUtc.HasValue) q = q.Where(t => t.CreatedAtUtc >= fromUtc);
        if (toUtc.HasValue) q = q.Where(t => t.CreatedAtUtc <= toUtc);
        if (departmentId.HasValue) q = q.Where(t => t.DepartmentId == departmentId);

        var rows = await q.OrderByDescending(t => t.CreatedAtUtc).Take(100000).ToListAsync();
        var sb = new StringBuilder();
        sb.AppendLine("TicketNumber,CustomerName,CustomerEmail,Department,Category,Priority,Status,SupportLevel,SlaState,CreatedAtUtc,ClosedAtUtc");
        foreach (var t in rows)
        {
            string esc(string s) => '"' + (s ?? "").Replace(""", """") + '"';
            sb.AppendLine(string.Join(',', new[]
            {
                esc(t.TicketNumber),
                esc(t.CustomerName),
                esc(t.CustomerEmail),
                esc(t.Department?.Name ?? ""),
                esc(t.IssueCategory?.Name ?? ""),
                esc(t.Priority.ToString()),
                esc(t.Status.ToString()),
                esc(t.SupportLevel.ToString()),
                esc(t.SlaState.ToString()),
                esc(t.CreatedAtUtc.ToString("O")),
                esc(t.ClosedAtUtc?.ToString("O") ?? "")
            }));
        }
        return Encoding.UTF8.GetBytes(sb.ToString());
    }
}
