using CMS.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace CMS.Infrastructure.Services;

public interface IEmailComposer
{
    Task<(string Subject, string Body)> ComposeAsync(string templateKey, IDictionary<string, string> tokens);
}

public class EmailComposer : IEmailComposer
{
    private readonly Data.AppDbContext _db;

    public EmailComposer(Data.AppDbContext db) => _db = db;

    public async Task<(string Subject, string Body)> ComposeAsync(string templateKey, IDictionary<string, string> tokens)
    {
        var template = await _db.EmailTemplates.AsNoTracking().FirstOrDefaultAsync(t => t.Key == templateKey && t.IsActive);
        if (template is null)
        {
            // safe fallback
            return ($"CMS Notification ({templateKey})", "<p>Template missing.</p>");
        }

        string subject = Replace(template.Subject, tokens);
        string body = Replace(template.BodyHtml, tokens);
        return (subject, body);
    }

    private static string Replace(string input, IDictionary<string, string> tokens)
    {
        foreach (var kv in tokens)
        {
            input = input.Replace("{{" + kv.Key + "}}", kv.Value ?? string.Empty);
        }
        return input;
    }
}
