using Microsoft.EntityFrameworkCore;

namespace CMS.Infrastructure.Services;

public interface ITicketNumberGenerator
{
    Task<string> NextAsync();
}

public class TicketNumberGenerator : ITicketNumberGenerator
{
    private readonly Data.AppDbContext _db;

    public TicketNumberGenerator(Data.AppDbContext db)
    {
        _db = db;
    }

    public async Task<string> NextAsync()
    {
        // Simple deterministic generator: count + 1. For high concurrency, use SEQUENCE.
        var count = await _db.Tickets.CountAsync();
        return $"TKT-{(count + 1).ToString().PadLeft(6, '0')}";
    }
}
