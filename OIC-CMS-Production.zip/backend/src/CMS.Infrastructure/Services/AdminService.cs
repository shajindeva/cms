using CMS.Application.Interfaces;
using CMS.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace CMS.Infrastructure.Services;

public class AdminService : IAdminService
{
    private readonly Data.AppDbContext _db;
    public AdminService(Data.AppDbContext db) => _db = db;

    public async Task<IReadOnlyList<Department>> GetDepartmentsAsync() =>
        await _db.Departments.AsNoTracking().OrderBy(d => d.Name).ToListAsync();

    public async Task<IReadOnlyList<IssueCategory>> GetCategoriesAsync(Guid? departmentId)
    {
        var q = _db.IssueCategories.AsNoTracking().AsQueryable();
        if (departmentId.HasValue) q = q.Where(x => x.DepartmentId == departmentId);
        return await q.OrderBy(x => x.Name).ToListAsync();
    }

    public async Task<Department> UpsertDepartmentAsync(Department dept)
    {
        var existing = await _db.Departments.FirstOrDefaultAsync(d => d.Id == dept.Id);
        if (existing is null)
        {
            _db.Departments.Add(dept);
        }
        else
        {
            existing.Name = dept.Name;
            existing.NotificationEmail = dept.NotificationEmail;
            existing.IsActive = dept.IsActive;
        }
        await _db.SaveChangesAsync();
        return dept;
    }

    public async Task<IssueCategory> UpsertCategoryAsync(IssueCategory cat)
    {
        var existing = await _db.IssueCategories.FirstOrDefaultAsync(c => c.Id == cat.Id);
        if (existing is null)
        {
            _db.IssueCategories.Add(cat);
        }
        else
        {
            existing.Name = cat.Name;
            existing.DepartmentId = cat.DepartmentId;
            existing.IsActive = cat.IsActive;
        }
        await _db.SaveChangesAsync();
        return cat;
    }

    public async Task<IReadOnlyList<SlaMatrixCell>> GetSlaMatrixAsync() =>
        await _db.SlaMatrix.AsNoTracking().OrderBy(x => x.Priority).ThenBy(x => x.SupportLevel).ToListAsync();

    public async Task<SlaMatrixCell> UpsertSlaCellAsync(SlaMatrixCell cell)
    {
        var existing = await _db.SlaMatrix.FirstOrDefaultAsync(s => s.Id == cell.Id);
        if (existing is null)
        {
            _db.SlaMatrix.Add(cell);
        }
        else
        {
            existing.Priority = cell.Priority;
            existing.SupportLevel = cell.SupportLevel;
            existing.AcknowledgementHours = cell.AcknowledgementHours;
            existing.ResolutionHours = cell.ResolutionHours;
            existing.WarningThresholdPercent = cell.WarningThresholdPercent;
            existing.IsActive = cell.IsActive;
        }
        await _db.SaveChangesAsync();
        return cell;
    }

    public async Task<IReadOnlyList<EmailTemplate>> GetEmailTemplatesAsync() =>
        await _db.EmailTemplates.AsNoTracking().OrderBy(x => x.Key).ToListAsync();

    public async Task<EmailTemplate> UpsertEmailTemplateAsync(EmailTemplate template)
    {
        var existing = await _db.EmailTemplates.FirstOrDefaultAsync(t => t.Id == template.Id);
        if (existing is null)
        {
            _db.EmailTemplates.Add(template);
        }
        else
        {
            existing.Key = template.Key;
            existing.Subject = template.Subject;
            existing.BodyHtml = template.BodyHtml;
            existing.IsActive = template.IsActive;
        }
        await _db.SaveChangesAsync();
        return template;
    }
}
