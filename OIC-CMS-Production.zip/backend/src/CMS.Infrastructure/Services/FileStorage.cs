using CMS.Domain.Entities;
using Microsoft.AspNetCore.Http;

namespace CMS.Infrastructure.Services;

public interface IFileStorage
{
    Task<TicketAttachment> SaveTicketAttachmentAsync(Guid ticketId, IFormFile file, bool isCustomerUpload, string actor);
    FileStream OpenRead(string storagePath);
}

public class LocalFileStorage : IFileStorage
{
    private readonly string _basePath;

    public LocalFileStorage(string basePath)
    {
        _basePath = basePath;
        Directory.CreateDirectory(_basePath);
    }

    public async Task<TicketAttachment> SaveTicketAttachmentAsync(Guid ticketId, IFormFile file, bool isCustomerUpload, string actor)
    {
        var safeName = string.Join('_', Path.GetFileName(file.FileName).Split(Path.GetInvalidFileNameChars()));
        var folder = Path.Combine(_basePath, ticketId.ToString("N"));
        Directory.CreateDirectory(folder);
        var path = Path.Combine(folder, $"{DateTime.UtcNow:yyyyMMddHHmmssfff}_{safeName}");

        await using (var fs = new FileStream(path, FileMode.CreateNew, FileAccess.Write))
        {
            await file.CopyToAsync(fs);
        }

        return new TicketAttachment
        {
            TicketId = ticketId,
            FileName = safeName,
            ContentType = file.ContentType,
            SizeBytes = file.Length,
            StoragePath = path,
            IsCustomerUpload = isCustomerUpload,
            CreatedAtUtc = DateTime.UtcNow,
            CreatedBy = actor
        };
    }

    public FileStream OpenRead(string storagePath) => new FileStream(storagePath, FileMode.Open, FileAccess.Read, FileShare.Read);
}
