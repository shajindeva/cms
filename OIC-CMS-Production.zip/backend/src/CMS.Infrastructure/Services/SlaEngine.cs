using CMS.Domain;
using CMS.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace CMS.Infrastructure.Services;

public interface ISlaEngine
{
    Task<(DateTime? dueAtUtc, SlaState state)> ComputeAsync(Ticket ticket);
    Task RecalculateAndPersistAsync(Guid ticketId);
}

public class SlaEngine : ISlaEngine
{
    private readonly Data.AppDbContext _db;

    public SlaEngine(Data.AppDbContext db) => _db = db;

    public async Task<(DateTime? dueAtUtc, SlaState state)> ComputeAsync(Ticket ticket)
    {
        var cell = await _db.SlaMatrix.AsNoTracking().FirstOrDefaultAsync(x => x.Priority == ticket.Priority && x.SupportLevel == ticket.SupportLevel && x.IsActive);
        if (cell is null)
        {
            return (ticket.SlaDueAtUtc, ticket.SlaState);
        }

        var start = ticket.SlaStartAtUtc;
        var due = start.AddHours((double)cell.ResolutionHours);

        var now = DateTime.UtcNow;
        if (ticket.IsSlaPaused)
        {
            // while paused, keep state as is
            return (due, ticket.SlaState);
        }

        if (now > due)
        {
            return (due, SlaState.Breached);
        }

        var elapsed = (now - start).TotalSeconds;
        var total = (due - start).TotalSeconds;
        var pct = total <= 0 ? 100 : (elapsed / total) * 100;
        var warn = pct >= cell.WarningThresholdPercent ? SlaState.Warning : SlaState.OnTime;
        return (due, warn);
    }

    public async Task RecalculateAndPersistAsync(Guid ticketId)
    {
        var ticket = await _db.Tickets.FirstOrDefaultAsync(t => t.Id == ticketId);
        if (ticket is null) return;

        var (dueAt, state) = await ComputeAsync(ticket);
        ticket.SlaDueAtUtc = dueAt;
        ticket.SlaState = state;
        ticket.UpdatedAtUtc = DateTime.UtcNow;

        await _db.SaveChangesAsync();
    }
}
