using Microsoft.AspNetCore.Identity;

namespace CMS.Infrastructure.Identity;

public class AppUser : IdentityUser
{
    public string DisplayName { get; set; } = string.Empty;
    public Guid? DepartmentId { get; set; }
    public int? SupportLevel { get; set; } // 1/2/3
    public bool IsActive { get; set; } = true;
}
