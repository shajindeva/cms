namespace CMS.Domain.Entities;

public class EmailTemplate : BaseEntity
{
    public string Key { get; set; } = string.Empty; // e.g. TicketCreatedCustomer
    public string Subject { get; set; } = string.Empty;
    public string BodyHtml { get; set; } = string.Empty;
    public bool IsActive { get; set; } = true;
}
