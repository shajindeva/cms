namespace CMS.Domain.Entities;

public class IssueCategory : BaseEntity
{
    public string Name { get; set; } = string.Empty;
    public Guid DepartmentId { get; set; }
    public Department? Department { get; set; }
    public bool IsActive { get; set; } = true;
}
