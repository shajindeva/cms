namespace CMS.Domain.Entities;

public class AuditLog : BaseEntity
{
    public string Action { get; set; } = string.Empty; // TicketCreated, StatusChanged...
    public Guid? TicketId { get; set; }
    public string? Field { get; set; }
    public string? FromValue { get; set; }
    public string? ToValue { get; set; }
    public string Actor { get; set; } = string.Empty;
    public string Source { get; set; } = "API";
}
