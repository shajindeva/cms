using CMS.Domain;

namespace CMS.Domain.Entities;

public class Ticket : BaseEntity
{
    public string TicketNumber { get; set; } = string.Empty; // TKT-000001

    // Customer
    public string CustomerName { get; set; } = string.Empty;
    public string CustomerEmail { get; set; } = string.Empty;
    public string? CustomerMobile { get; set; }

    // Issue
    public Guid DepartmentId { get; set; }
    public Department? Department { get; set; }

    public Guid IssueCategoryId { get; set; }
    public IssueCategory? IssueCategory { get; set; }

    public string Subject { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;

    public Priority Priority { get; set; } = Priority.Medium;
    public TicketStatus Status { get; set; } = TicketStatus.New;
    public SupportLevel SupportLevel { get; set; } = SupportLevel.L1;

    // Assignment
    public string? AssignedToUserId { get; set; }

    // SLA
    public DateTime? AcknowledgedAtUtc { get; set; }
    public DateTime? ResolvedAtUtc { get; set; }
    public DateTime? ClosedAtUtc { get; set; }
    public DateTime SlaStartAtUtc { get; set; } = DateTime.UtcNow;
    public DateTime? SlaDueAtUtc { get; set; }
    public SlaState SlaState { get; set; } = SlaState.OnTime;
    public bool IsSlaPaused { get; set; } = false;
    public DateTime? SlaPausedAtUtc { get; set; }
    public int ReopenCount { get; set; } = 0;

    // Resolution
    public string? ResolutionSummary { get; set; }
    public string? ClosureReason { get; set; }
    public string? RootCauseCategory { get; set; }

    public ICollection<TicketComment> Comments { get; set; } = new List<TicketComment>();
    public ICollection<TicketAttachment> Attachments { get; set; } = new List<TicketAttachment>();
    public ICollection<TicketEscalation> Escalations { get; set; } = new List<TicketEscalation>();
}
