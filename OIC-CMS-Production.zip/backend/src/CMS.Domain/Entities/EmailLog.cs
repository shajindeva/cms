namespace CMS.Domain.Entities;

public class EmailLog : BaseEntity
{
    public string To { get; set; } = string.Empty;
    public string Subject { get; set; } = string.Empty;
    public string Status { get; set; } = "Queued"; // Queued/Sent/Failed
    public string? Error { get; set; }
}
