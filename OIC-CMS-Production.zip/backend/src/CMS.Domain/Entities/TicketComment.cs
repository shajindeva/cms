namespace CMS.Domain.Entities;

public class TicketComment : BaseEntity
{
    public Guid TicketId { get; set; }
    public Ticket? Ticket { get; set; }

    public string AuthorDisplayName { get; set; } = string.Empty;
    public string? AuthorUserId { get; set; } // null = customer

    public bool IsInternal { get; set; } = false;
    public string Message { get; set; } = string.Empty;
}
