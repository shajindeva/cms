using CMS.Domain;

namespace CMS.Domain.Entities;

public class SlaMatrixCell : BaseEntity
{
    public Priority Priority { get; set; }
    public SupportLevel SupportLevel { get; set; }

    public decimal AcknowledgementHours { get; set; }
    public decimal ResolutionHours { get; set; }

    // Warning threshold % (e.g. 80)
    public int WarningThresholdPercent { get; set; } = 80;

    public bool IsActive { get; set; } = true;
}
