namespace CMS.Domain.Entities;

public class Department : BaseEntity
{
    public string Name { get; set; } = string.Empty;
    public string? NotificationEmail { get; set; }
    public bool IsActive { get; set; } = true;
    public ICollection<IssueCategory> Categories { get; set; } = new List<IssueCategory>();
}
