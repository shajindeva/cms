using CMS.Domain;

namespace CMS.Domain.Entities;

public class TicketEscalation : BaseEntity
{
    public Guid TicketId { get; set; }
    public Ticket? Ticket { get; set; }

    public SupportLevel FromLevel { get; set; }
    public SupportLevel ToLevel { get; set; }

    public string Reason { get; set; } = string.Empty;
    public bool IsEmergency { get; set; } = false;
}
