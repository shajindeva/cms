namespace CMS.Domain;

public enum TicketStatus
{
    New = 0,
    Acknowledged = 1,
    Assigned = 2,
    InProgress = 3,
    PendingCustomer = 4,
    Resolved = 5,
    Closed = 6,
    Reopened = 7
}

public enum Priority
{
    Critical = 0,
    High = 1,
    Medium = 2,
    Low = 3
}

public enum SupportLevel
{
    L1 = 1,
    L2 = 2,
    L3 = 3
}

public enum SlaState
{
    OnTime = 0,
    Warning = 1,
    Breached = 2
}

public static class RoleNames
{
    public const string Admin = "Admin";
    public const string Supervisor = "Supervisor";
    public const string L1Agent = "L1Agent";
    public const string L2Agent = "L2Agent";
    public const string L3Agent = "L3Agent";
    public const string Auditor = "Auditor";

    // Centralized users (CRM / call-center) can close/reopen tickets per internal discussion.
    public const string Central = "Central";
}
