using System.ComponentModel.DataAnnotations;

namespace CMS.Application.DTOs;

public class PublicCreateTicketRequest
{
    [Required, MaxLength(120)]
    public string CustomerName { get; set; } = string.Empty;

    [Required, EmailAddress, MaxLength(120)]
    public string CustomerEmail { get; set; } = string.Empty;

    [MaxLength(30)]
    public string? CustomerMobile { get; set; }

    [Required]
    public Guid DepartmentId { get; set; }

    [Required]
    public Guid IssueCategoryId { get; set; }

    [Required, MaxLength(160)]
    public string Subject { get; set; } = string.Empty;

    [Required, MinLength(20), MaxLength(6000)]
    public string Description { get; set; } = string.Empty;

    public IEnumerable<Guid>? AttachmentIds { get; set; }
}
