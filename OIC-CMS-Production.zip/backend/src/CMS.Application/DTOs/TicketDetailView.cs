using CMS.Domain;

namespace CMS.Application.DTOs;

public class TicketDetailView
{
    public Guid Id { get; set; }
    public string TicketNumber { get; set; } = string.Empty;

    public string CustomerName { get; set; } = string.Empty;
    public string CustomerEmail { get; set; } = string.Empty;
    public string? CustomerMobile { get; set; }

    public string Department { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty;

    public string Subject { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;

    public Priority Priority { get; set; }
    public TicketStatus Status { get; set; }
    public SupportLevel SupportLevel { get; set; }

    public string? AssignedToUserId { get; set; }
    public string? AssignedToDisplayName { get; set; }

    public SlaState SlaState { get; set; }
    public DateTime SlaStartAtUtc { get; set; }
    public DateTime? SlaDueAtUtc { get; set; }

    public DateTime CreatedAtUtc { get; set; }
    public DateTime? UpdatedAtUtc { get; set; }

    public DateTime? AcknowledgedAtUtc { get; set; }
    public DateTime? ResolvedAtUtc { get; set; }
    public DateTime? ClosedAtUtc { get; set; }

    public int ReopenCount { get; set; }

    public string? ResolutionSummary { get; set; }
    public string? ClosureReason { get; set; }
    public string? RootCauseCategory { get; set; }

    public List<TicketCommentView> Comments { get; set; } = new();
    public List<TicketAttachmentView> Attachments { get; set; } = new();
    public List<TicketEscalationView> Escalations { get; set; } = new();
}

public class TicketCommentView
{
    public DateTime AtUtc { get; set; }
    public string Author { get; set; } = string.Empty;
    public bool IsInternal { get; set; }
    public string Message { get; set; } = string.Empty;
}

public class TicketAttachmentView
{
    public Guid Id { get; set; }
    public string FileName { get; set; } = string.Empty;
    public string ContentType { get; set; } = string.Empty;
    public long SizeBytes { get; set; }
    public bool IsCustomerUpload { get; set; }
    public DateTime AtUtc { get; set; }
}

public class TicketEscalationView
{
    public DateTime AtUtc { get; set; }
    public string By { get; set; } = string.Empty;
    public string From { get; set; } = string.Empty;
    public string To { get; set; } = string.Empty;
    public bool IsEmergency { get; set; }
    public string Reason { get; set; } = string.Empty;
}
