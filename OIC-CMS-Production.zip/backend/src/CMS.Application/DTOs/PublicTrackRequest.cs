using System.ComponentModel.DataAnnotations;

namespace CMS.Application.DTOs;

public class PublicTrackRequest
{
    [Required]
    public string TicketNumber { get; set; } = string.Empty;

    [Required, EmailAddress]
    public string CustomerEmail { get; set; } = string.Empty;
}
