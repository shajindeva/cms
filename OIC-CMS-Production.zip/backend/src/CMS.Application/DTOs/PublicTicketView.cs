using CMS.Domain;

namespace CMS.Application.DTOs;

public class PublicTicketView
{
    public string TicketNumber { get; set; } = string.Empty;
    public string Subject { get; set; } = string.Empty;
    public string Department { get; set; } = string.Empty;
    public TicketStatus Status { get; set; }
    public DateTime CreatedAtUtc { get; set; }
    public DateTime? UpdatedAtUtc { get; set; }
    public List<PublicTimelineItem> Timeline { get; set; } = new();
}

public class PublicTimelineItem
{
    public DateTime AtUtc { get; set; }
    public string Message { get; set; } = string.Empty;
}
