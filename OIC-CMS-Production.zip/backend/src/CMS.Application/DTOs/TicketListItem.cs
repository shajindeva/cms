using CMS.Domain;

namespace CMS.Application.DTOs;

public class TicketListItem
{
    public Guid Id { get; set; }
    public string TicketNumber { get; set; } = string.Empty;
    public string Subject { get; set; } = string.Empty;
    public string CustomerName { get; set; } = string.Empty;
    public string CustomerEmail { get; set; } = string.Empty;
    public string Department { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty;
    public Priority Priority { get; set; }
    public TicketStatus Status { get; set; }
    public SupportLevel SupportLevel { get; set; }
    public string? AssignedTo { get; set; }
    public SlaState SlaState { get; set; }
    public DateTime CreatedAtUtc { get; set; }
    public DateTime? SlaDueAtUtc { get; set; }
}
