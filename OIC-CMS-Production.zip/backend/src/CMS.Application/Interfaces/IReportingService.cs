namespace CMS.Application.Interfaces;

public record DashboardKpis(int Total, int Open, int Closed, int Breached, int Warning, int CriticalOpen, decimal? SlaCompliancePercent);
public record TrendPoint(DateTime DayUtc, int Created, int Closed);

public interface IReportingService
{
    Task<DashboardKpis> GetDashboardKpisAsync(int days, Guid? departmentId);
    Task<IReadOnlyList<TrendPoint>> GetTrendAsync(int days, Guid? departmentId);
    Task<byte[]> ExportTicketsCsvAsync(DateTime? fromUtc, DateTime? toUtc, Guid? departmentId);
}
