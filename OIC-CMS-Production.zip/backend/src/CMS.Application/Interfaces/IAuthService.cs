using CMS.Application.DTOs;

namespace CMS.Application.Interfaces;

public interface IAuthService
{
    Task<TokenResponse?> LoginAsync(LoginRequest request);
    Task<TokenResponse?> RefreshAsync(RefreshRequest request);
    Task LogoutAsync(string refreshToken);
}
