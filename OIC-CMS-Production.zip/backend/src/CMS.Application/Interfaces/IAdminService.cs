using CMS.Domain.Entities;

namespace CMS.Application.Interfaces;

public interface IAdminService
{
    Task<IReadOnlyList<Department>> GetDepartmentsAsync();
    Task<IReadOnlyList<IssueCategory>> GetCategoriesAsync(Guid? departmentId);

    Task<Department> UpsertDepartmentAsync(Department dept);
    Task<IssueCategory> UpsertCategoryAsync(IssueCategory cat);

    Task<IReadOnlyList<SlaMatrixCell>> GetSlaMatrixAsync();
    Task<SlaMatrixCell> UpsertSlaCellAsync(SlaMatrixCell cell);

    Task<IReadOnlyList<EmailTemplate>> GetEmailTemplatesAsync();
    Task<EmailTemplate> UpsertEmailTemplateAsync(EmailTemplate template);
}
