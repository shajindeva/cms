using CMS.Application.DTOs;

namespace CMS.Application.Interfaces;

public interface ITicketService
{
    Task<string> CreatePublicTicketAsync(PublicCreateTicketRequest request, string? createdByIp);
    Task<PublicTicketView?> TrackAsync(PublicTrackRequest request);

    Task<(IReadOnlyList<TicketListItem> Items, int Total)> SearchAsync(string? q, Guid? deptId, string? status, string? priority, string? sla, int page, int pageSize);
    Task<TicketDetailView?> GetDetailAsync(Guid id);

    Task AssignAsync(Guid ticketId, string assigneeUserId, string reason, string actor);
    Task UpdateAsync(Guid ticketId, string actor, string? status, string? priority, string? resolutionSummary, string? closureReason, string? rootCauseCategory);
    Task AddCommentAsync(Guid ticketId, string actorDisplayName, string? actorUserId, bool isInternal, string message);
    Task EscalateAsync(Guid ticketId, string actor, string reason, bool emergency);
    Task ReopenAsync(Guid ticketId, string actor, string reason);
}
