import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { CmsApiService } from '../core/cms-api.service';

@Component({
  standalone: true,
  selector: 'app-ticket-detail',
  imports: [CommonModule, FormsModule, MatCardModule, MatButtonModule, MatInputModule, MatSelectModule],
  template: `
  <mat-card class="card" *ngIf="t">
    <mat-card-content>
      <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:10px;">
        <div>
          <div style="font-family:monospace;font-weight:900;color:#0054A4;">{{t.ticketNumber}}</div>
          <div style="font-size:18px;font-weight:800;margin-top:4px;">{{t.subject}}</div>
          <div style="color:#64748b;margin-top:2px;">{{t.customerName}} · {{t.customerEmail}} · {{t.department}}</div>
        </div>
        <div style="display:grid;gap:6px;min-width:200px;">
          <div><strong>Status:</strong> {{t.status}}</div>
          <div><strong>Priority:</strong> {{t.priority}}</div>
          <div><strong>Level:</strong> {{t.supportLevel}}</div>
          <div><strong>SLA:</strong> {{t.slaState}}</div>
        </div>
      </div>

      <div style="margin-top:12px;background:#f8fafc;padding:12px;border-radius:12px;white-space:pre-wrap;">{{t.description}}</div>

      <div style="margin-top:12px;display:grid;grid-template-columns:1fr 1fr;gap:10px;">
        <mat-form-field appearance="outline">
          <mat-label>Status</mat-label>
          <mat-select [(ngModel)]="edit.status">
            <mat-option *ngFor="let s of statuses" [value]="s">{{s}}</mat-option>
          </mat-select>
        </mat-form-field>
        <mat-form-field appearance="outline">
          <mat-label>Priority</mat-label>
          <mat-select [(ngModel)]="edit.priority">
            <mat-option *ngFor="let p of priorities" [value]="p">{{p}}</mat-option>
          </mat-select>
        </mat-form-field>
      </div>

      <mat-form-field appearance="outline" style="width:100%;">
        <mat-label>Resolution summary</mat-label>
        <textarea matInput rows="2" [(ngModel)]="edit.resolutionSummary"></textarea>
      </mat-form-field>

      <div style="display:flex;gap:8px;flex-wrap:wrap;">
        <button mat-raised-button color="primary" (click)="save()">Save</button>
        <button mat-stroked-button color="warn" (click)="escalate()">Escalate</button>
        <button mat-stroked-button (click)="reopen()">Reopen</button>
      </div>

      <div style="margin-top:14px;">
        <div style="font-weight:800;margin-bottom:8px;">Timeline</div>
        <div *ngFor="let c of t.comments" style="padding:10px;border:1px solid #e2e8f0;border-radius:12px;margin-bottom:8px;background:#fff;">
          <div style="font-size:12px;color:#64748b;">{{c.atUtc | date:'medium'}} · {{c.author}} <span *ngIf="c.isInternal" style="color:#7c3aed;font-weight:700;">(Internal)</span></div>
          <div style="margin-top:4px;white-space:pre-wrap;">{{c.message}}</div>
        </div>

        <mat-form-field appearance="outline" style="width:100%;">
          <mat-label>Add comment</mat-label>
          <textarea matInput rows="2" [(ngModel)]="comment"></textarea>
        </mat-form-field>
        <div style="display:flex;gap:8px;align-items:center;">
          <label style="display:flex;gap:6px;align-items:center;color:#7c3aed;font-weight:700;">
            <input type="checkbox" [(ngModel)]="isInternal" /> Internal
          </label>
          <button mat-raised-button color="primary" (click)="addComment()">Send</button>
        </div>
      </div>
    </mat-card-content>
  </mat-card>
  `
})
export class TicketDetailComponent implements OnInit {
  id!: string;
  t: any;

  statuses = ['New','Acknowledged','Assigned','InProgress','PendingCustomer','Resolved','Closed','Reopened'];
  priorities = ['Critical','High','Medium','Low'];

  edit: any = { status: '', priority: '' };

  comment = '';
  isInternal = false;

  constructor(private route: ActivatedRoute, private api: CmsApiService) {}

  ngOnInit(): void {
    this.id = this.route.snapshot.paramMap.get('id')!;
    this.load();
  }

  load() {
    this.api.ticketDetail(this.id).subscribe(t => {
      this.t = t;
      this.edit.status = t.status;
      this.edit.priority = t.priority;
      this.edit.resolutionSummary = t.resolutionSummary;
    });
  }

  save() {
    this.api.updateTicket(this.id, this.edit).subscribe({
      next: _ => this.load(),
      error: err => alert('Update blocked (role restriction) or failed.')
    });
  }

  addComment() {
    if (!this.comment.trim()) return;
    this.api.addComment(this.id, { isInternal: this.isInternal, message: this.comment }).subscribe({
      next: _ => { this.comment = ''; this.isInternal = false; this.load(); }
    });
  }

  escalate() {
    const reason = prompt('Escalation reason');
    if (!reason) return;
    this.api.escalate(this.id, { reason, emergency: false }).subscribe({ next: _ => this.load() });
  }

  reopen() {
    const reason = prompt('Reopen reason');
    if (!reason) return;
    this.api.reopen(this.id, { reason }).subscribe({ next: _ => this.load() });
  }
}
