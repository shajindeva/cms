import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatTableModule } from '@angular/material/table';
import { CmsApiService } from '../core/cms-api.service';

@Component({
  standalone: true,
  selector: 'app-ticket-list',
  imports: [CommonModule, FormsModule, MatCardModule, MatInputModule, MatButtonModule, MatTableModule],
  template: `
  <mat-card class="card">
    <mat-card-content>
      <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
        <mat-form-field appearance="outline" style="width:260px;">
          <mat-label>Search</mat-label>
          <input matInput [(ngModel)]="q" (keyup.enter)="load()" placeholder="Ticket, customer, email..." />
        </mat-form-field>
        <button mat-raised-button color="primary" (click)="load()">Search</button>
        <div style="margin-left:auto;color:#64748b;">{{total}} result(s)</div>
      </div>

      <table mat-table [dataSource]="items" class="mat-elevation-z0" style="width:100%;margin-top:10px;">
        <ng-container matColumnDef="ticketNumber">
          <th mat-header-cell *matHeaderCellDef>Ticket</th>
          <td mat-cell *matCellDef="let r"><a (click)="open(r.id)" style="cursor:pointer;color:#0054A4;font-family:monospace;font-weight:700;">{{r.ticketNumber}}</a></td>
        </ng-container>
        <ng-container matColumnDef="subject">
          <th mat-header-cell *matHeaderCellDef>Subject</th>
          <td mat-cell *matCellDef="let r">{{r.subject}}</td>
        </ng-container>
        <ng-container matColumnDef="customer">
          <th mat-header-cell *matHeaderCellDef>Customer</th>
          <td mat-cell *matCellDef="let r">{{r.customerName}}<div style="font-size:12px;color:#64748b;">{{r.customerEmail}}</div></td>
        </ng-container>
        <ng-container matColumnDef="status">
          <th mat-header-cell *matHeaderCellDef>Status</th>
          <td mat-cell *matCellDef="let r">{{r.status}}</td>
        </ng-container>
        <ng-container matColumnDef="sla">
          <th mat-header-cell *matHeaderCellDef>SLA</th>
          <td mat-cell *matCellDef="let r">{{r.slaState}}</td>
        </ng-container>

        <tr mat-header-row *matHeaderRowDef="cols"></tr>
        <tr mat-row *matRowDef="let row; columns: cols;"></tr>
      </table>
    </mat-card-content>
  </mat-card>
  `
})
export class TicketListComponent implements OnInit {
  q = '';
  items: any[] = [];
  total = 0;
  cols = ['ticketNumber', 'subject', 'customer', 'status', 'sla'];

  constructor(private api: CmsApiService, private router: Router) {}

  ngOnInit(): void { this.load(); }

  load() {
    this.api.tickets({ q: this.q, page: 1, pageSize: 50 }).subscribe(r => {
      this.items = r.items;
      this.total = r.total;
    });
  }

  open(id: string) {
    this.router.navigate(['/app/tickets', id]);
  }
}
