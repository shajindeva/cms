import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { CmsApiService } from '../core/cms-api.service';

@Component({
  standalone: true,
  selector: 'app-dashboard',
  imports: [CommonModule, MatCardModule],
  template: `
  <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;">
    <mat-card class="card"><mat-card-content><div style="color:#64748b;">Total Tickets</div><div style="font-family:monospace;font-size:26px;font-weight:800;">{{kpis?.total ?? '—'}}</div></mat-card-content></mat-card>
    <mat-card class="card"><mat-card-content><div style="color:#64748b;">Open</div><div style="font-family:monospace;font-size:26px;font-weight:800;">{{kpis?.open ?? '—'}}</div></mat-card-content></mat-card>
    <mat-card class="card"><mat-card-content><div style="color:#64748b;">Closed</div><div style="font-family:monospace;font-size:26px;font-weight:800;">{{kpis?.closed ?? '—'}}</div></mat-card-content></mat-card>
    <mat-card class="card"><mat-card-content><div style="color:#64748b;">SLA Breached</div><div style="font-family:monospace;font-size:26px;font-weight:800;color:#dc2626;">{{kpis?.breached ?? '—'}}</div></mat-card-content></mat-card>
  </div>
  <div style="margin-top:12px;display:grid;grid-template-columns:repeat(3,1fr);gap:12px;">
    <mat-card class="card"><mat-card-content><div style="color:#64748b;">SLA Warning</div><div style="font-family:monospace;font-size:22px;font-weight:800;">{{kpis?.warning ?? '—'}}</div></mat-card-content></mat-card>
    <mat-card class="card"><mat-card-content><div style="color:#64748b;">Critical Open</div><div style="font-family:monospace;font-size:22px;font-weight:800;">{{kpis?.criticalOpen ?? '—'}}</div></mat-card-content></mat-card>
    <mat-card class="card"><mat-card-content><div style="color:#64748b;">SLA Compliance</div><div style="font-family:monospace;font-size:22px;font-weight:800;color:#16a34a;">{{kpis?.slaCompliancePercent ? (kpis.slaCompliancePercent + '%') : '—'}}</div></mat-card-content></mat-card>
  </div>
  <mat-card class="card" style="margin-top:12px;"><mat-card-content>
    <div style="font-weight:700;">Trend endpoint ready</div>
    <div style="color:#64748b;">Hook Chart.js to /reports/dashboard trend data for charts (the API already returns it).</div>
  </mat-card-content></mat-card>
  `
})
export class DashboardComponent implements OnInit {
  kpis: any;
  constructor(private api: CmsApiService) {}
  ngOnInit(): void {
    this.api.dashboard(30).subscribe(r => this.kpis = r.kpis);
  }
}
