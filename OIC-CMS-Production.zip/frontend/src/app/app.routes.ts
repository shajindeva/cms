import { Routes } from '@angular/router';
import { PublicPortalComponent } from './public/public-portal.component';
import { LoginComponent } from './security/login.component';
import { ShellComponent } from './shell/shell.component';
import { DashboardComponent } from './tickets/dashboard.component';
import { TicketListComponent } from './tickets/ticket-list.component';
import { TicketDetailComponent } from './tickets/ticket-detail.component';
import { AdminSlaComponent } from './admin/admin-sla.component';
import { AdminUsersComponent } from './admin/admin-users.component';
import { AuditComponent } from './admin/audit.component';
import { ReportsComponent } from './reports/reports.component';
import { authGuard } from './core/auth.guard';

export const routes: Routes = [
  { path: '', component: PublicPortalComponent },
  { path: 'login', component: LoginComponent },
  {
    path: 'app',
    component: ShellComponent,
    canActivate: [authGuard],
    children: [
      { path: '', component: DashboardComponent },
      { path: 'tickets', component: TicketListComponent },
      { path: 'tickets/:id', component: TicketDetailComponent },
      { path: 'reports', component: ReportsComponent },
      { path: 'admin/sla', component: AdminSlaComponent },
      { path: 'admin/users', component: AdminUsersComponent },
      { path: 'admin/audit', component: AuditComponent }
    ]
  },
  { path: '**', redirectTo: '' }
];
