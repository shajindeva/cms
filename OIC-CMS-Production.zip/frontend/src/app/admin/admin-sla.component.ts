import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';

@Component({
  standalone: true,
  selector: 'app-admin-sla',
  imports: [CommonModule, MatCardModule],
  template: `
  <mat-card class="card"><mat-card-content>
    <div style="font-weight:800;">SLA Configuration</div>
    <div style="color:#64748b;margin-top:6px;">Admin UI can be wired to /api/admin/sla (API implemented). Keep this screen as a placeholder scaffold.</div>
  </mat-card-content></mat-card>
  `
})
export class AdminSlaComponent implements OnInit {
  ngOnInit(): void {}
}
