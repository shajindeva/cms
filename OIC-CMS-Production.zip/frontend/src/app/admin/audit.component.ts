import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';

@Component({
  standalone: true,
  selector: 'app-audit',
  imports: [CommonModule, MatCardModule],
  template: `
  <mat-card class="card"><mat-card-content>
    <div style="font-weight:800;">Audit Trail</div>
    <div style="color:#64748b;margin-top:6px;">Audit log writing is implemented server-side. Add a UI grid on top of /db audit table or implement a /api/audit endpoint.</div>
  </mat-card-content></mat-card>
  `
})
export class AuditComponent {}
