import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';

@Component({
  standalone: true,
  selector: 'app-admin-users',
  imports: [CommonModule, MatCardModule],
  template: `
  <mat-card class="card"><mat-card-content>
    <div style="font-weight:800;">Users</div>
    <div style="color:#64748b;margin-top:6px;">User management uses ASP.NET Identity (seeded admin/supervisor). Extend with UI as needed.</div>
  </mat-card-content></mat-card>
  `
})
export class AdminUsersComponent {}
