import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTabsModule } from '@angular/material/tabs';
import { CmsApiService } from '../core/cms-api.service';

@Component({
  standalone: true,
  selector: 'app-public-portal',
  imports: [CommonModule, FormsModule, MatButtonModule, MatCardModule, MatInputModule, MatSelectModule, MatTabsModule],
  template: `
  <div class="container" style="min-height:100vh;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#0a1628 0%,#0054A4 60%,#1a6bb8 100%);">
    <mat-card class="card" style="max-width:720px;width:100%;padding:0;border-radius:18px;overflow:hidden;">
      <div style="background:#0054A4;color:#fff;padding:22px 24px;">
        <div style="font-size:20px;font-weight:700;">OIC CMS</div>
        <div style="opacity:.85;margin-top:2px;">Customer Portal — submit or track your complaint</div>
      </div>
      <div style="padding:18px 22px;">
        <mat-tab-group [(selectedIndex)]="tab">
          <mat-tab label="Submit Complaint">
            <div style="padding:14px 0;display:grid;gap:10px;">
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
                <mat-form-field appearance="outline">
                  <mat-label>Full name</mat-label>
                  <input matInput [(ngModel)]="form.customerName" />
                </mat-form-field>
                <mat-form-field appearance="outline">
                  <mat-label>Email</mat-label>
                  <input matInput type="email" [(ngModel)]="form.customerEmail" />
                </mat-form-field>
              </div>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
                <mat-form-field appearance="outline">
                  <mat-label>Department</mat-label>
                  <mat-select [(ngModel)]="form.departmentId" (selectionChange)="deptChanged()">
                    <mat-option *ngFor="let d of departments" [value]="d.id">{{d.name}}</mat-option>
                  </mat-select>
                </mat-form-field>
                <mat-form-field appearance="outline">
                  <mat-label>Issue type</mat-label>
                  <mat-select [(ngModel)]="form.issueCategoryId">
                    <mat-option *ngFor="let c of filteredCategories" [value]="c.id">{{c.name}}</mat-option>
                  </mat-select>
                </mat-form-field>
              </div>
              <mat-form-field appearance="outline">
                <mat-label>Subject</mat-label>
                <input matInput [(ngModel)]="form.subject" />
              </mat-form-field>
              <mat-form-field appearance="outline">
                <mat-label>Description</mat-label>
                <textarea matInput rows="4" [(ngModel)]="form.description"></textarea>
              </mat-form-field>
              <button mat-raised-button color="primary" (click)="submit()" [disabled]="loading">Submit</button>
              <div *ngIf="ticketNumber" style="margin-top:8px;padding:12px;border-radius:12px;background:#eff6ff;border:1px solid #bfdbfe;">
                <div style="font-weight:700;">Complaint submitted ✅</div>
                <div style="margin-top:6px;">Your ticket number:</div>
                <div style="font-family:monospace;font-size:22px;font-weight:800;color:#0054A4;">{{ticketNumber}}</div>
              </div>
            </div>
          </mat-tab>
          <mat-tab label="Track Ticket">
            <div style="padding:14px 0;display:grid;gap:10px;">
              <mat-form-field appearance="outline">
                <mat-label>Ticket number</mat-label>
                <input matInput [(ngModel)]="trackForm.ticketNumber" placeholder="TKT-000001" />
              </mat-form-field>
              <mat-form-field appearance="outline">
                <mat-label>Email</mat-label>
                <input matInput type="email" [(ngModel)]="trackForm.customerEmail" />
              </mat-form-field>
              <button mat-raised-button color="primary" (click)="track()" [disabled]="loading">Track</button>
              <mat-card *ngIf="tracked" style="margin-top:10px;border-radius:14px;">
                <mat-card-content>
                  <div style="display:flex;justify-content:space-between;align-items:center;">
                    <div style="font-family:monospace;font-weight:800;color:#0054A4;">{{tracked.ticketNumber}}</div>
                    <div style="font-weight:700;">{{tracked.status}}</div>
                  </div>
                  <div style="margin-top:6px;font-weight:600;">{{tracked.subject}}</div>
                  <div style="margin-top:2px;color:#666;">{{tracked.department}}</div>
                  <div style="margin-top:10px;display:grid;gap:8px;">
                    <div *ngFor="let t of tracked.timeline" style="padding:10px;border-radius:12px;background:#f8fafc;">
                      <div style="font-size:12px;color:#64748b;">{{t.atUtc | date:'medium'}}</div>
                      <div style="margin-top:4px;">{{t.message}}</div>
                    </div>
                  </div>
                </mat-card-content>
              </mat-card>
            </div>
          </mat-tab>
          <mat-tab label="Staff Login">
            <div style="padding:18px 0;">
              <button mat-stroked-button (click)="router.navigateByUrl('/login')">Go to Login</button>
            </div>
          </mat-tab>
        </mat-tab-group>
      </div>
    </mat-card>
  </div>
  `
})
export class PublicPortalComponent implements OnInit {
  tab = 0;
  loading = false;

  departments: any[] = [];
  categories: any[] = [];
  filteredCategories: any[] = [];

  form: any = {
    customerName: '',
    customerEmail: '',
    departmentId: '',
    issueCategoryId: '',
    subject: '',
    description: ''
  };

  ticketNumber: string | null = null;

  trackForm: any = {
    ticketNumber: '',
    customerEmail: ''
  };

  tracked: any = null;

  constructor(private api: CmsApiService, public router: Router) {}

  ngOnInit(): void {
    this.api.publicMetadata().subscribe(m => {
      this.departments = m.departments;
      this.categories = m.categories;
      this.filteredCategories = [];
    });
  }

  deptChanged() {
    this.filteredCategories = this.categories.filter((c: any) => c.departmentId === this.form.departmentId);
    this.form.issueCategoryId = '';
  }

  submit() {
    this.loading = true;
    this.ticketNumber = null;
    this.api.createPublicComplaint(this.form).subscribe({
      next: r => { this.ticketNumber = r.ticketNumber; this.loading = false; },
      error: _ => { this.loading = false; alert('Submission failed. Please check required fields.'); }
    });
  }

  track() {
    this.loading = true;
    this.tracked = null;
    this.api.track(this.trackForm).subscribe({
      next: r => { this.tracked = r; this.loading = false; },
      error: _ => { this.loading = false; alert('Ticket not found.'); }
    });
  }
}
