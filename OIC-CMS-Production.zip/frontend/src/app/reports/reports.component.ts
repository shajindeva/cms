import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { CmsApiService } from '../core/cms-api.service';

@Component({
  standalone: true,
  selector: 'app-reports',
  imports: [CommonModule, MatCardModule, MatButtonModule],
  template: `
  <mat-card class="card"><mat-card-content>
    <div style="font-weight:800;">Reports</div>
    <div style="color:#64748b;margin-top:6px;">CSV export is available from the API.</div>
    <button mat-raised-button color="primary" style="margin-top:10px;" (click)="export()">Export Tickets (CSV)</button>
  </mat-card-content></mat-card>
  `
})
export class ReportsComponent {
  constructor(private api: CmsApiService) {}

  export() {
    this.api.exportCsv().subscribe(blob => {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'CMS_Tickets.csv';
      a.click();
      URL.revokeObjectURL(a.href);
    });
  }
}
