import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { AuthService } from '../core/auth.service';

@Component({
  standalone: true,
  selector: 'app-shell',
  imports: [CommonModule, RouterOutlet, RouterLink, MatSidenavModule, MatListModule, MatIconModule, MatToolbarModule, MatButtonModule],
  template: `
  <mat-sidenav-container style="height:100vh;">
    <mat-sidenav mode="side" opened style="width:250px;background:#0a1628;color:#fff;">
      <div style="padding:16px;font-weight:800;">🛡 OIC CMS</div>
      <mat-nav-list>
        <a mat-list-item routerLink="/app" style="color:#fff;">Dashboard</a>
        <a mat-list-item routerLink="/app/tickets" style="color:#fff;">Tickets</a>
        <a mat-list-item routerLink="/app/reports" style="color:#fff;">Reports</a>
        <div style="padding:8px 16px;color:#94a3b8;font-size:12px;font-weight:700;">Admin</div>
        <a mat-list-item routerLink="/app/admin/sla" style="color:#fff;">SLA Config</a>
        <a mat-list-item routerLink="/app/admin/users" style="color:#fff;">Users</a>
        <a mat-list-item routerLink="/app/admin/audit" style="color:#fff;">Audit</a>
      </mat-nav-list>
      <div style="position:absolute;bottom:0;left:0;right:0;padding:12px;">
        <button mat-stroked-button style="width:100%;border-color:#334155;color:#fff;" (click)="logout()">Logout</button>
      </div>
    </mat-sidenav>
    <mat-sidenav-content>
      <mat-toolbar color="primary" style="position:sticky;top:0;z-index:10;">OIC CMS</mat-toolbar>
      <div class="container">
        <router-outlet />
      </div>
    </mat-sidenav-content>
  </mat-sidenav-container>
  `
})
export class ShellComponent {
  constructor(private auth: AuthService) {}
  logout() { this.auth.logout(); location.href = '/'; }
}
