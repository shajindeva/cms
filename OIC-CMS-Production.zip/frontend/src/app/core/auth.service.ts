import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { tap } from 'rxjs/operators';

export interface TokenResponse {
  accessToken: string;
  expiresAtUtc: string;
  refreshToken?: string;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private key = 'cms_auth';

  constructor(private http: HttpClient) {}

  login(username: string, password: string) {
    return this.http.post<TokenResponse>(`${environment.apiBaseUrl}/auth/login`, { username, password }).pipe(
      tap(t => this.store(t))
    );
  }

  refresh() {
    const st = this.getStored();
    if (!st?.refreshToken) return null;
    return this.http.post<TokenResponse>(`${environment.apiBaseUrl}/auth/refresh`, { refreshToken: st.refreshToken }).pipe(
      tap(t => this.store(t))
    );
  }

  logout() {
    const st = this.getStored();
    localStorage.removeItem(this.key);
    if (!st?.refreshToken) return;
    this.http.post(`${environment.apiBaseUrl}/auth/logout`, { refreshToken: st.refreshToken }).subscribe();
  }

  get accessToken(): string | null {
    return this.getStored()?.accessToken ?? null;
  }

  isLoggedIn(): boolean {
    return !!this.accessToken;
  }

  private store(t: TokenResponse) {
    localStorage.setItem(this.key, JSON.stringify(t));
  }

  private getStored(): TokenResponse | null {
    const raw = localStorage.getItem(this.key);
    return raw ? JSON.parse(raw) : null;
  }
}
