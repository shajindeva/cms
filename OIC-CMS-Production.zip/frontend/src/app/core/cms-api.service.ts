import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Department, Category, PublicTicketView, TicketListItem } from './api.models';

@Injectable({ providedIn: 'root' })
export class CmsApiService {
  constructor(private http: HttpClient) {}

  publicMetadata() {
    return this.http.get<{departments: Department[]; categories: Category[]}>(`${environment.apiBaseUrl}/public/metadata`);
  }

  createPublicComplaint(payload: any) {
    return this.http.post<{ticketNumber: string}>(`${environment.apiBaseUrl}/public/complaints`, payload);
  }

  track(payload: any) {
    return this.http.post<PublicTicketView>(`${environment.apiBaseUrl}/public/track`, payload);
  }

  dashboard(days = 30, departmentId?: string) {
    let params = new HttpParams().set('days', String(days));
    if (departmentId) params = params.set('departmentId', departmentId);
    return this.http.get<any>(`${environment.apiBaseUrl}/reports/dashboard`, { params });
  }

  tickets(query: any) {
    let params = new HttpParams();
    Object.keys(query).forEach(k => {
      if (query[k] !== undefined && query[k] !== null && query[k] !== '') {
        params = params.set(k, String(query[k]));
      }
    });
    return this.http.get<{total: number; items: TicketListItem[]}>(`${environment.apiBaseUrl}/tickets`, { params });
  }

  ticketDetail(id: string) {
    return this.http.get<any>(`${environment.apiBaseUrl}/tickets/${id}`);
  }

  updateTicket(id: string, payload: any) {
    return this.http.post(`${environment.apiBaseUrl}/tickets/${id}/update`, payload);
  }

  addComment(id: string, payload: any) {
    return this.http.post(`${environment.apiBaseUrl}/tickets/${id}/comment`, payload);
  }

  escalate(id: string, payload: any) {
    return this.http.post(`${environment.apiBaseUrl}/tickets/${id}/escalate`, payload);
  }

  reopen(id: string, payload: any) {
    return this.http.post(`${environment.apiBaseUrl}/tickets/${id}/reopen`, payload);
  }

  exportCsv(fromUtc?: string, toUtc?: string, departmentId?: string) {
    let params = new HttpParams();
    if (fromUtc) params = params.set('fromUtc', fromUtc);
    if (toUtc) params = params.set('toUtc', toUtc);
    if (departmentId) params = params.set('departmentId', departmentId);
    return this.http.get(`${environment.apiBaseUrl}/reports/tickets.csv`, { params, responseType: 'blob' });
  }
}
