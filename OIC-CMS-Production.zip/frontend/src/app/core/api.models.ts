export interface Department { id: string; name: string; notificationEmail?: string; isActive?: boolean; }
export interface Category { id: string; name: string; departmentId: string; isActive?: boolean; }

export interface PublicTicketView {
  ticketNumber: string;
  subject: string;
  department: string;
  status: string;
  createdAtUtc: string;
  updatedAtUtc?: string;
  timeline: { atUtc: string; message: string }[];
}

export interface TicketListItem {
  id: string;
  ticketNumber: string;
  subject: string;
  customerName: string;
  customerEmail: string;
  department: string;
  category: string;
  priority: string;
  status: string;
  supportLevel: string;
  assignedTo?: string;
  slaState: string;
  createdAtUtc: string;
  slaDueAtUtc?: string;
}
