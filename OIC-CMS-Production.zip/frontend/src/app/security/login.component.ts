import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { AuthService } from '../core/auth.service';

@Component({
  standalone: true,
  selector: 'app-login',
  imports: [CommonModule, FormsModule, MatCardModule, MatButtonModule, MatInputModule],
  template: `
  <div class="container" style="min-height:100vh;display:flex;align-items:center;justify-content:center;background:#0a1628;">
    <mat-card class="card" style="max-width:420px;width:100%;padding:18px;">
      <h2 style="margin:0 0 6px 0;">Staff Login</h2>
      <div style="color:#64748b;margin-bottom:14px;">Use your assigned credentials.</div>
      <mat-form-field appearance="outline" style="width:100%;">
        <mat-label>Username</mat-label>
        <input matInput [(ngModel)]="username" />
      </mat-form-field>
      <mat-form-field appearance="outline" style="width:100%;">
        <mat-label>Password</mat-label>
        <input matInput type="password" [(ngModel)]="password" />
      </mat-form-field>
      <button mat-raised-button color="primary" style="width:100%;" (click)="login()" [disabled]="loading">Login</button>
      <button mat-button style="width:100%;margin-top:6px;" (click)="router.navigateByUrl('/')">Back to Portal</button>
      <div style="margin-top:12px;font-size:12px;color:#64748b;">Default admin: admin / ChangeMe!12345</div>
    </mat-card>
  </div>
  `
})
export class LoginComponent {
  username = '';
  password = '';
  loading = false;

  constructor(private auth: AuthService, public router: Router) {}

  login() {
    this.loading = true;
    this.auth.login(this.username, this.password).subscribe({
      next: _ => { this.loading = false; this.router.navigateByUrl('/app'); },
      error: _ => { this.loading = false; alert('Invalid credentials.'); }
    });
  }
}
