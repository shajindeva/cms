# OIC CMS UI (Angular)

This is the Angular SPA for the Complaints Management System.

## Quick start
1. Install Node LTS and Angular CLI.
2. From this folder:
   - `npm install`
   - `npm start`
3. Set API base URL in `src/environments/environment.ts`.

## Production build
- `npm run build` produces `dist/`.
